/* =============================================================================
 *                      GENERATED FILE - DO NOT MODIFY
 * =============================================================================
 * Copyright © Microsoft Corporation. All rights reserved.
 * 
 */
package com.skype;
import android.support.v4.util.SparseArrayCompat;
import java.util.Set;
import java.util.HashSet;
import java.lang.ref.ReferenceQueue;
import com.skype.NativeStringConvert;

import com.skype.UpdateParticipantInterpretationStateParameters;

public class UpdateParticipantInterpretationStateParametersImpl extends InMemoryObjectImpl implements UpdateParticipantInterpretationStateParameters, NativeListenable {
	public UpdateParticipantInterpretationStateParametersImpl() {
		this(SkypeFactory.getInstance() );
	}

	public UpdateParticipantInterpretationStateParametersImpl(ObjectInterfaceFactory factory) {
		super(factory,factory.createUpdateParticipantInterpretationStateParameters());
		factory.initializeListener(this);
	}

	static class UpdateParticipantInterpretationStateParametersWeakRef extends NativeWeakRef<ShutdownDestructible> {
		private ObjectInterfaceFactory factory;
		UpdateParticipantInterpretationStateParametersWeakRef(ObjectInterfaceFactory factory, ShutdownDestructible ref, ReferenceQueue<ShutdownDestructible> queue, long nativeObject) {
			super(ref, queue, nativeObject);
			this.factory = factory;
		}
		public void destroyNativeObject() {
			factory.destroyUpdateParticipantInterpretationStateParameters(nativeObject);
		}
	}

	public NativeWeakRef<ShutdownDestructible> createNativeWeakRef(ObjectInterfaceFactory factory, ReferenceQueue<ShutdownDestructible> queue) {
		return new UpdateParticipantInterpretationStateParametersWeakRef(factory, this, queue, m_nativeObject);
	}

	public native void initializeListener();
	
	private final Set<UpdateParticipantInterpretationStateParametersIListener> m_listeners = new HashSet<UpdateParticipantInterpretationStateParametersIListener>();

	@Override
	public void addListener(UpdateParticipantInterpretationStateParametersIListener listener) {
		synchronized (m_listeners) {
			m_listeners.add(listener);
		}
	}

	@Override
	public void removeListener(UpdateParticipantInterpretationStateParametersIListener listener) {
		synchronized (m_listeners) {
			m_listeners.remove(listener);
		}
	}

	@Override
	public native SkyLib.IN_MEMORY_OBJECTTYPE getInMemObjectType();

	@Override
	public native int getObjectID();

	@Override
	public void setInterpretationStateJsons(String[] interpretationStateJsons) {
		setInterpretationStateJsons(NativeStringConvert.ConvertArrToNativeByteArr(interpretationStateJsons));
	}

	private native void setInterpretationStateJsons(byte[][] interpretationStateJsons);
}

