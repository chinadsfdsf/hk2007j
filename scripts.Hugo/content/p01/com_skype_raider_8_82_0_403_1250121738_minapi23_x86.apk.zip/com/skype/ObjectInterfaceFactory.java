/* =============================================================================
 *                      GENERATED FILE - DO NOT MODIFY
 * =============================================================================
 * Copyright © Microsoft Corporation. All rights reserved.
 * 
 */
package com.skype;
import android.support.v4.util.SparseArrayCompat;
import java.util.Set;
import java.util.HashSet;
import java.lang.ref.ReferenceQueue;
import com.skype.NativeStringConvert;

public interface ObjectInterfaceFactory {
	public long createMetatag();
	public long createMetatag(int key, long value);
	public long createMetatag(int key, byte[] value);
	public long createMetatag(int key, String value);
	public void destroyMetatag(long nativeObject);
	public long createObjectInterface();
	public void destroyObjectInterface(long nativeObject);
	public long createAccount();
	public void destroyAccount(long nativeObject);
	public long createVideo();
	public void destroyVideo(long nativeObject);
	public long createVideoReceiver();
	public void destroyVideoReceiver(long nativeObject);
	public long createVideoPreview();
	public void destroyVideoPreview(long nativeObject);
	public long createSkCompositor();
	public void destroySkCompositor(long nativeObject);
	public long createRemoteControlSession();
	public void destroyRemoteControlSession(long nativeObject);
	public long createContentSharing();
	public void destroyContentSharing(long nativeObject);
	public long createDataChannel();
	public void destroyDataChannel(long nativeObject);
	public long createCall();
	public void destroyCall(long nativeObject);
	public long createInMemoryObject();
	public void destroyInMemoryObject(long nativeObject);
	public long createSessionParameters();
	public void destroySessionParameters(long nativeObject);
	public long createAddParticipantParameters();
	public void destroyAddParticipantParameters(long nativeObject);
	public long createMergeParameters();
	public void destroyMergeParameters(long nativeObject);
	public long createAnswerParameters();
	public void destroyAnswerParameters(long nativeObject);
	public long createMediaStateConfiguration();
	public void destroyMediaStateConfiguration(long nativeObject);
	public long createTransferParameters();
	public void destroyTransferParameters(long nativeObject);
	public long createStopParameters();
	public void destroyStopParameters(long nativeObject);
	public long createSafeTransferParameters();
	public void destroySafeTransferParameters(long nativeObject);
	public long createMeetingSettingsParameters();
	public void destroyMeetingSettingsParameters(long nativeObject);
	public long createAdmitParameters();
	public void destroyAdmitParameters(long nativeObject);
	public long createHoldUnholdParameters();
	public void destroyHoldUnholdParameters(long nativeObject);
	public long createParkUnparkParameters();
	public void destroyParkUnparkParameters(long nativeObject);
	public long createSearchOptionsParameters();
	public void destroySearchOptionsParameters(long nativeObject);
	public long createCallStateParameters();
	public void destroyCallStateParameters(long nativeObject);
	public long createUpdateMeetingGroupParameters();
	public void destroyUpdateMeetingGroupParameters(long nativeObject);
	public long createUpdateMeetingLiveStateParameters();
	public void destroyUpdateMeetingLiveStateParameters(long nativeObject);
	public long createSetMeetingLayoutParameters();
	public void destroySetMeetingLayoutParameters(long nativeObject);
	public long createUpdateParticipantInterpretationStateParameters();
	public void destroyUpdateParticipantInterpretationStateParameters(long nativeObject);
	public long createJoinMeetingGroupParameters();
	public void destroyJoinMeetingGroupParameters(long nativeObject);
	public long createLeaveMeetingGroupParameters();
	public void destroyLeaveMeetingGroupParameters(long nativeObject);
	public long createRedirectOptions();
	public void destroyRedirectOptions(long nativeObject);
	public long createCallHandler();
	public void destroyCallHandler(long nativeObject);
	public long createExampleInMemoryObject();
	public long createExampleInMemoryObject(String name);
	public long createExampleInMemoryObject(String name, int[] children);
	public void destroyExampleInMemoryObject(long nativeObject);
	public long createmsrtc();
	public void destroymsrtc(long nativeObject);
	public void destroyListener(long nativeObject);
	public void destroySetup(long nativeObject);
	public void destroyGI(long nativeObject);
	public long createSkyLib(String uiVersionString, boolean isMemOnlyMode, boolean useEventPolling);
	public long createSkyLib(String uiVersionString, String dbPath, boolean isRemovableDbPath, boolean useEventPolling);
	public void destroySkyLib(long nativeObject);
	public long createAddGroupModalityParameters();
	public void destroyAddGroupModalityParameters(long nativeObject);
	public long createClientDesc();
	public void destroyClientDesc(long nativeObject);
	public void initializeListener(NativeListenable nativeListenable);
}

