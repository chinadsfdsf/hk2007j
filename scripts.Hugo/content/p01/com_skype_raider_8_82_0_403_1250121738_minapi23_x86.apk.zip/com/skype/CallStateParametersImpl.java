/* =============================================================================
 *                      GENERATED FILE - DO NOT MODIFY
 * =============================================================================
 * Copyright © Microsoft Corporation. All rights reserved.
 * 
 */
package com.skype;
import android.support.v4.util.SparseArrayCompat;
import java.util.Set;
import java.util.HashSet;
import java.lang.ref.ReferenceQueue;
import com.skype.NativeStringConvert;

import com.skype.CallStateParameters;

public class CallStateParametersImpl extends InMemoryObjectImpl implements CallStateParameters, NativeListenable {
	public CallStateParametersImpl() {
		this(SkypeFactory.getInstance() );
	}

	public CallStateParametersImpl(ObjectInterfaceFactory factory) {
		super(factory,factory.createCallStateParameters());
		factory.initializeListener(this);
	}

	static class CallStateParametersWeakRef extends NativeWeakRef<ShutdownDestructible> {
		private ObjectInterfaceFactory factory;
		CallStateParametersWeakRef(ObjectInterfaceFactory factory, ShutdownDestructible ref, ReferenceQueue<ShutdownDestructible> queue, long nativeObject) {
			super(ref, queue, nativeObject);
			this.factory = factory;
		}
		public void destroyNativeObject() {
			factory.destroyCallStateParameters(nativeObject);
		}
	}

	public NativeWeakRef<ShutdownDestructible> createNativeWeakRef(ObjectInterfaceFactory factory, ReferenceQueue<ShutdownDestructible> queue) {
		return new CallStateParametersWeakRef(factory, this, queue, m_nativeObject);
	}

	public native void initializeListener();
	
	private final Set<CallStateParametersIListener> m_listeners = new HashSet<CallStateParametersIListener>();

	@Override
	public void addListener(CallStateParametersIListener listener) {
		synchronized (m_listeners) {
			m_listeners.add(listener);
		}
	}

	@Override
	public void removeListener(CallStateParametersIListener listener) {
		synchronized (m_listeners) {
			m_listeners.remove(listener);
		}
	}

	@Override
	public native SkyLib.IN_MEMORY_OBJECTTYPE getInMemObjectType();

	@Override
	public native int getObjectID();

	@Override
	public void setContext(String context) {
		setContext(NativeStringConvert.ConvertToNativeBytes(context));
	}

	private native void setContext(byte[] context);
}

