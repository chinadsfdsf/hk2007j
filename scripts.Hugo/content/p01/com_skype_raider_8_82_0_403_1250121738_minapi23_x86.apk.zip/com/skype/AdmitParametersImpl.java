/* =============================================================================
 *                      GENERATED FILE - DO NOT MODIFY
 * =============================================================================
 * Copyright © Microsoft Corporation. All rights reserved.
 * 
 */
package com.skype;
import android.support.v4.util.SparseArrayCompat;
import java.util.Set;
import java.util.HashSet;
import java.lang.ref.ReferenceQueue;
import com.skype.NativeStringConvert;

import com.skype.AdmitParameters;

public class AdmitParametersImpl extends InMemoryObjectImpl implements AdmitParameters, NativeListenable {
	public AdmitParametersImpl() {
		this(SkypeFactory.getInstance() );
	}

	public AdmitParametersImpl(ObjectInterfaceFactory factory) {
		super(factory,factory.createAdmitParameters());
		factory.initializeListener(this);
	}

	static class AdmitParametersWeakRef extends NativeWeakRef<ShutdownDestructible> {
		private ObjectInterfaceFactory factory;
		AdmitParametersWeakRef(ObjectInterfaceFactory factory, ShutdownDestructible ref, ReferenceQueue<ShutdownDestructible> queue, long nativeObject) {
			super(ref, queue, nativeObject);
			this.factory = factory;
		}
		public void destroyNativeObject() {
			factory.destroyAdmitParameters(nativeObject);
		}
	}

	public NativeWeakRef<ShutdownDestructible> createNativeWeakRef(ObjectInterfaceFactory factory, ReferenceQueue<ShutdownDestructible> queue) {
		return new AdmitParametersWeakRef(factory, this, queue, m_nativeObject);
	}

	public native void initializeListener();
	
	private final Set<AdmitParametersIListener> m_listeners = new HashSet<AdmitParametersIListener>();

	@Override
	public void addListener(AdmitParametersIListener listener) {
		synchronized (m_listeners) {
			m_listeners.add(listener);
		}
	}

	@Override
	public void removeListener(AdmitParametersIListener listener) {
		synchronized (m_listeners) {
			m_listeners.remove(listener);
		}
	}

	@Override
	public native SkyLib.IN_MEMORY_OBJECTTYPE getInMemObjectType();

	@Override
	public native int getObjectID();

	@Override
	public native void setAdmitScope(CallHandler.ADMIT_SCOPE admitScope);

	@Override
	public void setAdmitScope() {
		setAdmitScope(CallHandler.ADMIT_SCOPE.ADMIT_SCOPE_NONE);
	}
}

