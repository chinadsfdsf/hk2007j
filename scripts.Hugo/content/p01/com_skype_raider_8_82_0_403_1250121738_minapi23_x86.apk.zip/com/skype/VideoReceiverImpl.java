/* =============================================================================
 *                      GENERATED FILE - DO NOT MODIFY
 * =============================================================================
 * Copyright © Microsoft Corporation. All rights reserved.
 * 
 */
package com.skype;
import android.support.v4.util.SparseArrayCompat;
import java.util.Set;
import java.util.HashSet;
import java.lang.ref.ReferenceQueue;
import com.skype.NativeStringConvert;

import com.skype.VideoReceiver;

public class VideoReceiverImpl extends ObjectInterfaceImpl implements VideoReceiver, ObjectInterface, NativeListenable {
	public VideoReceiverImpl() {
		this(SkypeFactory.getInstance() );
	}

	public VideoReceiverImpl(ObjectInterfaceFactory factory) {
		super(factory,factory.createVideoReceiver());
		factory.initializeListener(this);
	}

	static class VideoReceiverWeakRef extends NativeWeakRef<ShutdownDestructible> {
		private ObjectInterfaceFactory factory;
		VideoReceiverWeakRef(ObjectInterfaceFactory factory, ShutdownDestructible ref, ReferenceQueue<ShutdownDestructible> queue, long nativeObject) {
			super(ref, queue, nativeObject);
			this.factory = factory;
		}
		public void destroyNativeObject() {
			factory.destroyVideoReceiver(nativeObject);
		}
	}

	public NativeWeakRef<ShutdownDestructible> createNativeWeakRef(ObjectInterfaceFactory factory, ReferenceQueue<ShutdownDestructible> queue) {
		return new VideoReceiverWeakRef(factory, this, queue, m_nativeObject);
	}

	public native void initializeListener();
	
	private final Set<VideoReceiverIListener> m_listeners = new HashSet<VideoReceiverIListener>();

	@Override
	public void addListener(VideoReceiverIListener listener) {
		synchronized (m_listeners) {
			m_listeners.add(listener);
		}
	}

	@Override
	public void removeListener(VideoReceiverIListener listener) {
		synchronized (m_listeners) {
			m_listeners.remove(listener);
		}
	}

	public void onChannelLost() {
		synchronized (m_listeners) {
			for (VideoReceiverIListener listener : m_listeners) {
				listener.onChannelLost(this);
			}
		}
	}

	public void onDispose() {
		synchronized (m_listeners) {
			for (VideoReceiverIListener listener : m_listeners) {
				listener.onDispose(this);
			}
		}
	}

	public void onError(VideoReceiver.FAILUREREASON error) {
		synchronized (m_listeners) {
			for (VideoReceiverIListener listener : m_listeners) {
				listener.onError(this, error);
			}
		}
	}

	public void onStatus(VideoReceiver.STATUS status) {
		synchronized (m_listeners) {
			for (VideoReceiverIListener listener : m_listeners) {
				listener.onStatus(this, status);
			}
		}
	}

	public void onSubscription(int videoObjectId) {
		synchronized (m_listeners) {
			for (VideoReceiverIListener listener : m_listeners) {
				listener.onSubscription(this, videoObjectId);
			}
		}
	}

	public void onVirtualParticipant(int virtualParticipantSourceId) {
		synchronized (m_listeners) {
			for (VideoReceiverIListener listener : m_listeners) {
				listener.onVirtualParticipant(this, virtualParticipantSourceId);
			}
		}
	}

	@Override
	public native void dispose();

	@Override
	public native void subscribe(int videoObjectId);

	public native void createBinding(int type, long binding);
	public native void releaseBinding(int type, long binding);
}

