package com.skype;

public interface NativeListenable {
    public void initializeListener();
}
