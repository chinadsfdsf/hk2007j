/* =============================================================================
 *                      GENERATED FILE - DO NOT MODIFY
 * =============================================================================
 * Copyright © Microsoft Corporation. All rights reserved.
 * 
 */
package com.skype;
import android.support.v4.util.SparseArrayCompat;
import java.util.Set;
import java.util.HashSet;
import java.lang.ref.ReferenceQueue;
import com.skype.NativeStringConvert;

import com.skype.SetMeetingLayoutParameters;

public class SetMeetingLayoutParametersImpl extends InMemoryObjectImpl implements SetMeetingLayoutParameters, NativeListenable {
	public SetMeetingLayoutParametersImpl() {
		this(SkypeFactory.getInstance() );
	}

	public SetMeetingLayoutParametersImpl(ObjectInterfaceFactory factory) {
		super(factory,factory.createSetMeetingLayoutParameters());
		factory.initializeListener(this);
	}

	static class SetMeetingLayoutParametersWeakRef extends NativeWeakRef<ShutdownDestructible> {
		private ObjectInterfaceFactory factory;
		SetMeetingLayoutParametersWeakRef(ObjectInterfaceFactory factory, ShutdownDestructible ref, ReferenceQueue<ShutdownDestructible> queue, long nativeObject) {
			super(ref, queue, nativeObject);
			this.factory = factory;
		}
		public void destroyNativeObject() {
			factory.destroySetMeetingLayoutParameters(nativeObject);
		}
	}

	public NativeWeakRef<ShutdownDestructible> createNativeWeakRef(ObjectInterfaceFactory factory, ReferenceQueue<ShutdownDestructible> queue) {
		return new SetMeetingLayoutParametersWeakRef(factory, this, queue, m_nativeObject);
	}

	public native void initializeListener();
	
	private final Set<SetMeetingLayoutParametersIListener> m_listeners = new HashSet<SetMeetingLayoutParametersIListener>();

	@Override
	public void addListener(SetMeetingLayoutParametersIListener listener) {
		synchronized (m_listeners) {
			m_listeners.add(listener);
		}
	}

	@Override
	public void removeListener(SetMeetingLayoutParametersIListener listener) {
		synchronized (m_listeners) {
			m_listeners.remove(listener);
		}
	}

	@Override
	public native SkyLib.IN_MEMORY_OBJECTTYPE getInMemObjectType();

	@Override
	public native int getObjectID();

	@Override
	public void setMeetingLayoutJson(String meetingLayoutJson) {
		setMeetingLayoutJson(NativeStringConvert.ConvertToNativeBytes(meetingLayoutJson));
	}

	private native void setMeetingLayoutJson(byte[] meetingLayoutJson);
}

