/* =============================================================================
 *                      GENERATED FILE - DO NOT MODIFY
 * =============================================================================
 * Copyright © Microsoft Corporation. All rights reserved.
 * 
 */
package com.skype;
import android.support.v4.util.SparseArrayCompat;
import java.util.Set;
import java.util.HashSet;
import java.lang.ref.ReferenceQueue;
import com.skype.NativeStringConvert;

import com.skype.RemoteControlSession;

public class RemoteControlSessionImpl extends ObjectInterfaceImpl implements RemoteControlSession, ObjectInterface, NativeListenable {
	public RemoteControlSessionImpl() {
		this(SkypeFactory.getInstance() );
	}

	public RemoteControlSessionImpl(ObjectInterfaceFactory factory) {
		super(factory,factory.createRemoteControlSession());
		factory.initializeListener(this);
	}

	static class RemoteControlSessionWeakRef extends NativeWeakRef<ShutdownDestructible> {
		private ObjectInterfaceFactory factory;
		RemoteControlSessionWeakRef(ObjectInterfaceFactory factory, ShutdownDestructible ref, ReferenceQueue<ShutdownDestructible> queue, long nativeObject) {
			super(ref, queue, nativeObject);
			this.factory = factory;
		}
		public void destroyNativeObject() {
			factory.destroyRemoteControlSession(nativeObject);
		}
	}

	public NativeWeakRef<ShutdownDestructible> createNativeWeakRef(ObjectInterfaceFactory factory, ReferenceQueue<ShutdownDestructible> queue) {
		return new RemoteControlSessionWeakRef(factory, this, queue, m_nativeObject);
	}

	@Override
	public int getIdProp() {
		return getIntProperty(PROPKEY.REMOTECONTROLSESSION_ID);
	}

	@Override
	public String getCauseidProp() {
		return getStrProperty(PROPKEY.REMOTECONTROLSESSION_CAUSEID);
	}

	@Override
	public RemoteControlSession.STATUS getStatusProp() {
		return RemoteControlSession.STATUS.fromInt(getIntProperty(PROPKEY.REMOTECONTROLSESSION_STATUS));
	}

	@Override
	public RemoteControlSession.FEATURE_TYPE getFeatureTypeProp() {
		return RemoteControlSession.FEATURE_TYPE.fromInt(getIntProperty(PROPKEY.REMOTECONTROLSESSION_FEATURE_TYPE));
	}

	@Override
	public RemoteControlSession.REASON getReasonProp() {
		return RemoteControlSession.REASON.fromInt(getIntProperty(PROPKEY.REMOTECONTROLSESSION_REASON));
	}

	@Override
	public String getSubreasonProp() {
		return getStrProperty(PROPKEY.REMOTECONTROLSESSION_SUBREASON);
	}

	public native void initializeListener();
	
	private final Set<RemoteControlSessionIListener> m_listeners = new HashSet<RemoteControlSessionIListener>();

	@Override
	public void addListener(RemoteControlSessionIListener listener) {
		synchronized (m_listeners) {
			m_listeners.add(listener);
		}
	}

	@Override
	public void removeListener(RemoteControlSessionIListener listener) {
		synchronized (m_listeners) {
			m_listeners.remove(listener);
		}
	}

	public void onControlSessionStatusChanged(RemoteControlSession.STATUS status, RemoteControlSession.REASON reason) {
		synchronized (m_listeners) {
			for (RemoteControlSessionIListener listener : m_listeners) {
				listener.onControlSessionStatusChanged(this, status, reason);
			}
		}
	}

	public void onIncomingControlRequestCancelled(byte[] participantId) {
		synchronized (m_listeners) {
			for (RemoteControlSessionIListener listener : m_listeners) {
				listener.onIncomingControlRequestCancelled(this, NativeStringConvert.ConvertFromNativeBytes(participantId));
			}
		}
	}

	public void onIncomingControlRequest(byte[] participantId) {
		synchronized (m_listeners) {
			for (RemoteControlSessionIListener listener : m_listeners) {
				listener.onIncomingControlRequest(this, NativeStringConvert.ConvertFromNativeBytes(participantId));
			}
		}
	}

	public void onPTZDeviceControlCommand(int ptzCommand) {
		synchronized (m_listeners) {
			for (RemoteControlSessionIListener listener : m_listeners) {
				listener.onPTZDeviceControlCommand(this, ptzCommand);
			}
		}
	}

	public void onRemotePTZDeviceStateChanged(int remotePTZDeviceState) {
		synchronized (m_listeners) {
			for (RemoteControlSessionIListener listener : m_listeners) {
				listener.onRemotePTZDeviceStateChanged(this, remotePTZDeviceState);
			}
		}
	}

	@Override
	public native boolean acceptControlRequest();

	@Override
	public native boolean denyControlRequest();

	@Override
	public boolean requestControl(String participantId) {
		return requestControl(NativeStringConvert.ConvertToNativeBytes(participantId));
	}

	private native boolean requestControl(byte[] participantId);
	@Override
	public native boolean sendPTZCommand(int ptzCommand);

	@Override
	public native boolean sendPTZDeviceState(int ptzState);

	@Override
	public native boolean startRemoteControlSession();

	@Override
	public native void stopRemoteControlSession();

}

