/* =============================================================================
 *                      GENERATED FILE - DO NOT MODIFY
 * =============================================================================
 * Copyright © Microsoft Corporation. All rights reserved.
 * 
 */
package com.skype;
import android.support.v4.util.SparseArrayCompat;
import java.util.Set;
import java.util.HashSet;
import java.lang.ref.ReferenceQueue;
import com.skype.NativeStringConvert;

public interface RedirectOptions {
	public interface RedirectOptionsIListener {
	}

	public void addListener(RedirectOptionsIListener listener);

	public void removeListener(RedirectOptionsIListener listener);

	
	public SkyLib.IN_MEMORY_OBJECTTYPE getInMemObjectType();

	public int getObjectID();

	public void setId(String id);

	public void setRedirectionEndpointType(CallHandler.REDIRECTION_ENDPOINT_TYPE redirectionEndpointType);

	public void setRedirectionTargetIdType(CallHandler.REDIRECTION_TARGET_ID_TYPE redirectionTargetIdType);

}

