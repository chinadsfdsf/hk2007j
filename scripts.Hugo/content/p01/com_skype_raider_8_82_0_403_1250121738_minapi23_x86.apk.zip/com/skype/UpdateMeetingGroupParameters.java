/* =============================================================================
 *                      GENERATED FILE - DO NOT MODIFY
 * =============================================================================
 * Copyright © Microsoft Corporation. All rights reserved.
 * 
 */
package com.skype;
import android.support.v4.util.SparseArrayCompat;
import java.util.Set;
import java.util.HashSet;
import java.lang.ref.ReferenceQueue;
import com.skype.NativeStringConvert;

public interface UpdateMeetingGroupParameters {
	public interface UpdateMeetingGroupParametersIListener {
	}

	public void addListener(UpdateMeetingGroupParametersIListener listener);

	public void removeListener(UpdateMeetingGroupParametersIListener listener);

	
	public SkyLib.IN_MEMORY_OBJECTTYPE getInMemObjectType();

	public int getObjectID();

	public void setFromGroup(String fromGroup);

	public void setParticipantScope(CallHandler.PARTICIPANT_SCOPE participantScope);

	public void setParticipantsJson(String participantsJson);

	public void setToGroup(String toGroup);

}

