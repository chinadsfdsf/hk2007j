/** 
 * (c) 2017 Skype
 * AUTOMATICALLY GENERATED CODE - DO NOT EDIT
 * Feb 27, 2022 1:26:53 PM
 */
package com.skype.android.gen;
public class SkCompositorListener implements com.skype.SkCompositor.SkCompositorIListener, com.skype.ObjectInterface.ObjectInterfaceIListener {
  final com.skype.android.event.EventBus eventBus=com.skype.android.event.EventBusInstance.get();
public static class OnCompositorError {
    private com.skype.SkCompositor _sender;
    private String _error;
    public OnCompositorError(    com.skype.SkCompositor sender,    String error){
      _sender=sender;
      _error=error;
    }
    public com.skype.SkCompositor getSender(){
      return _sender;
    }
    public String getError(){
      return _error;
    }
  }
  public void onCompositorError(  com.skype.SkCompositor sender,  String error){
    try {
      OnCompositorError event=new OnCompositorError(sender,error);
      eventBus.sendEvent(event);
    }
 catch (    java.lang.Throwable t) {
      com.skype.android.event.ListenerErrorReporter.report(new com.skype.android.event.ListenerError(t));
    }
  }
public static class OnDispose {
    private com.skype.SkCompositor _sender;
    public OnDispose(    com.skype.SkCompositor sender){
      _sender=sender;
    }
    public com.skype.SkCompositor getSender(){
      return _sender;
    }
  }
  public void onDispose(  com.skype.SkCompositor sender){
    try {
      OnDispose event=new OnDispose(sender);
      eventBus.sendEvent(event);
    }
 catch (    java.lang.Throwable t) {
      com.skype.android.event.ListenerErrorReporter.report(new com.skype.android.event.ListenerError(t));
    }
  }
public static class OnLayoutUpdate {
    private com.skype.SkCompositor _sender;
    private String _layout;
    public OnLayoutUpdate(    com.skype.SkCompositor sender,    String layout){
      _sender=sender;
      _layout=layout;
    }
    public com.skype.SkCompositor getSender(){
      return _sender;
    }
    public String getLayout(){
      return _layout;
    }
  }
  public void onLayoutUpdate(  com.skype.SkCompositor sender,  String layout){
    try {
      OnLayoutUpdate event=new OnLayoutUpdate(sender,layout);
      eventBus.sendEvent(event);
    }
 catch (    java.lang.Throwable t) {
      com.skype.android.event.ListenerErrorReporter.report(new com.skype.android.event.ListenerError(t));
    }
  }
public static class OnPropertyChange {
    private com.skype.ObjectInterface _sender;
    private com.skype.PROPKEY _propKey;
    public OnPropertyChange(    com.skype.ObjectInterface sender,    com.skype.PROPKEY propKey){
      _sender=sender;
      _propKey=propKey;
    }
    public com.skype.ObjectInterface getSender(){
      return _sender;
    }
    public com.skype.PROPKEY getPropKey(){
      return _propKey;
    }
  }
  public void onPropertyChange(  com.skype.ObjectInterface sender,  com.skype.PROPKEY propKey){
    try {
      OnPropertyChange event=new OnPropertyChange(sender,propKey);
      eventBus.sendEvent(event);
    }
 catch (    java.lang.Throwable t) {
      com.skype.android.event.ListenerErrorReporter.report(new com.skype.android.event.ListenerError(propKey,t));
    }
  }
}
