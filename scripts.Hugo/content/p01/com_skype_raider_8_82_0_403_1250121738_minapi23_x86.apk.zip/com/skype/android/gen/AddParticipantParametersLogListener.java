/** 
 * (c) 2017 Skype
 * AUTOMATICALLY GENERATED CODE - DO NOT EDIT
 * Feb 27, 2022 1:26:53 PM
 */
package com.skype.android.gen;
public class AddParticipantParametersLogListener implements com.skype.AddParticipantParameters.AddParticipantParametersIListener {
}
