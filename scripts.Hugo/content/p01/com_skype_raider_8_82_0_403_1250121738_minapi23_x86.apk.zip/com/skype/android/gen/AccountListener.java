/** 
 * (c) 2017 Skype
 * AUTOMATICALLY GENERATED CODE - DO NOT EDIT
 * Feb 27, 2022 1:26:53 PM
 */
package com.skype.android.gen;
public class AccountListener implements com.skype.Account.AccountIListener, com.skype.ObjectInterface.ObjectInterfaceIListener {
  final com.skype.android.event.EventBus eventBus=com.skype.android.event.EventBusInstance.get();
public static class OnSkypeTokenRequired {
    private com.skype.Account _sender;
    private String _invalidToken;
    public OnSkypeTokenRequired(    com.skype.Account sender,    String invalidToken){
      _sender=sender;
      _invalidToken=invalidToken;
    }
    public com.skype.Account getSender(){
      return _sender;
    }
    public String getInvalidToken(){
      return _invalidToken;
    }
  }
  public void onSkypeTokenRequired(  com.skype.Account sender,  String invalidToken){
    try {
      OnSkypeTokenRequired event=new OnSkypeTokenRequired(sender,invalidToken);
      eventBus.sendEvent(event);
    }
 catch (    java.lang.Throwable t) {
      com.skype.android.event.ListenerErrorReporter.report(new com.skype.android.event.ListenerError(t));
    }
  }
public static class OnTokenRequired {
    private com.skype.Account _sender;
    private String _factorsJson;
    private String _requestMetadataJson;
    private int _tokenTypeAsBitmask;
    private String _invalidToken;
    public OnTokenRequired(    com.skype.Account sender,    String factorsJson,    String requestMetadataJson,    int tokenTypeAsBitmask,    String invalidToken){
      _sender=sender;
      _factorsJson=factorsJson;
      _requestMetadataJson=requestMetadataJson;
      _tokenTypeAsBitmask=tokenTypeAsBitmask;
      _invalidToken=invalidToken;
    }
    public com.skype.Account getSender(){
      return _sender;
    }
    public String getFactorsJson(){
      return _factorsJson;
    }
    public String getRequestMetadataJson(){
      return _requestMetadataJson;
    }
    public int getTokenTypeAsBitmask(){
      return _tokenTypeAsBitmask;
    }
    public String getInvalidToken(){
      return _invalidToken;
    }
  }
  public void onTokenRequired(  com.skype.Account sender,  String factorsJson,  String requestMetadataJson,  int tokenTypeAsBitmask,  String invalidToken){
    try {
      OnTokenRequired event=new OnTokenRequired(sender,factorsJson,requestMetadataJson,tokenTypeAsBitmask,invalidToken);
      eventBus.sendEvent(event);
    }
 catch (    java.lang.Throwable t) {
      com.skype.android.event.ListenerErrorReporter.report(new com.skype.android.event.ListenerError(t));
    }
  }
public static class OnPropertyChange {
    private com.skype.ObjectInterface _sender;
    private com.skype.PROPKEY _propKey;
    public OnPropertyChange(    com.skype.ObjectInterface sender,    com.skype.PROPKEY propKey){
      _sender=sender;
      _propKey=propKey;
    }
    public com.skype.ObjectInterface getSender(){
      return _sender;
    }
    public com.skype.PROPKEY getPropKey(){
      return _propKey;
    }
  }
  public void onPropertyChange(  com.skype.ObjectInterface sender,  com.skype.PROPKEY propKey){
    try {
      OnPropertyChange event=new OnPropertyChange(sender,propKey);
      eventBus.sendEvent(event);
    }
 catch (    java.lang.Throwable t) {
      com.skype.android.event.ListenerErrorReporter.report(new com.skype.android.event.ListenerError(propKey,t));
    }
  }
}
