/** 
 * (c) 2017 Skype
 * AUTOMATICALLY GENERATED CODE - DO NOT EDIT
 * Feb 27, 2022 1:26:53 PM
 */
package com.skype.android.gen;
public class GIListener implements com.skype.GI.GIIListener {
  final com.skype.android.event.EventBus eventBus=com.skype.android.event.EventBusInstance.get();
public static class OnLibStatusChange {
    private com.skype.GI _sender;
    private com.skype.GI.LIBSTATUS _newStatus;
    public OnLibStatusChange(    com.skype.GI sender,    com.skype.GI.LIBSTATUS newStatus){
      _sender=sender;
      _newStatus=newStatus;
    }
    public com.skype.GI getSender(){
      return _sender;
    }
    public com.skype.GI.LIBSTATUS getNewStatus(){
      return _newStatus;
    }
  }
  public void onLibStatusChange(  com.skype.GI sender,  com.skype.GI.LIBSTATUS newStatus){
    try {
      OnLibStatusChange event=new OnLibStatusChange(sender,newStatus);
      eventBus.sendEvent(event);
    }
 catch (    java.lang.Throwable t) {
      com.skype.android.event.ListenerErrorReporter.report(new com.skype.android.event.ListenerError(t));
    }
  }
}
