/* =============================================================================
 *                      GENERATED FILE - DO NOT MODIFY
 * =============================================================================
 * Copyright © Microsoft Corporation. All rights reserved.
 * 
 */
package com.skype;
import android.support.v4.util.SparseArrayCompat;
import java.util.Set;
import java.util.HashSet;
import java.lang.ref.ReferenceQueue;
import com.skype.NativeStringConvert;

public interface ParkUnparkParameters {
	public interface ParkUnparkParametersIListener {
	}

	public void addListener(ParkUnparkParametersIListener listener);

	public void removeListener(ParkUnparkParametersIListener listener);

	
	public SkyLib.IN_MEMORY_OBJECTTYPE getInMemObjectType();

	public int getObjectID();

	public void setCauseId(String causeId);

	public void setParkContext(CallHandler.PARK_CONTEXT parkContext);

}

