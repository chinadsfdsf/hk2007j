package com.skype;

public class IUserStoreFactory {
  private transient long swigCPtr;

  protected IUserStoreFactory(long cPtr, @SuppressWarnings("unused") boolean futureUse) {
    swigCPtr = cPtr;
  }

  protected IUserStoreFactory() {
    swigCPtr = 0;
  }

  protected static long getCPtr(IUserStoreFactory obj) {
    return (obj == null) ? 0 : obj.swigCPtr;
  }
}

