/* =============================================================================
 *                      GENERATED FILE - DO NOT MODIFY
 * =============================================================================
 * Copyright © Microsoft Corporation. All rights reserved.
 * 
 */
package com.skype;
import android.support.v4.util.SparseArrayCompat;
import java.util.Set;
import java.util.HashSet;
import java.lang.ref.ReferenceQueue;
import com.skype.NativeStringConvert;

public interface RemoteControlSession extends ObjectInterface {
	public enum STATUS {
		INITIAL(0),
		READY(1),
		ACTIVE(2),
		CONTROLLED(3),
		CONTROLLING(4),
		TERMINATED(5),
		REQUEST_SENT(6),
		ACCEPT_ACK_WAITING(7),
		WRAPPER_UNKNOWN_VALUE(Integer.MAX_VALUE);
		
		private final int value;
		
		STATUS(int value) {
			this.value = value;
		}

		public int toInt() {
			return value;
		}

		private static final SparseArrayCompat<STATUS> intToTypeMap = new SparseArrayCompat< STATUS>();
		
		static {
			for (STATUS type : STATUS.values()) {
				intToTypeMap.put(type.value, type);
			}
		}

		public static STATUS fromInt(int i) {
			STATUS tmpVar = intToTypeMap.get(i);
			return (tmpVar != null) ? tmpVar : STATUS.WRAPPER_UNKNOWN_VALUE;
		}
	}

	public enum REASON {
		NONE(0),
		FAILURE(1),
		NETWORK_ERROR(2),
		REQUEST_TIMED_OUT(3),
		ACTION_NOT_ALLOWED(4),
		DATACHANNEL_ERROR(5),
		USER_ACTION_REJECT(6),
		UNKNOWN_FAILURE(7),
		WRAPPER_UNKNOWN_VALUE(Integer.MAX_VALUE);
		
		private final int value;
		
		REASON(int value) {
			this.value = value;
		}

		public int toInt() {
			return value;
		}

		private static final SparseArrayCompat<REASON> intToTypeMap = new SparseArrayCompat< REASON>();
		
		static {
			for (REASON type : REASON.values()) {
				intToTypeMap.put(type.value, type);
			}
		}

		public static REASON fromInt(int i) {
			REASON tmpVar = intToTypeMap.get(i);
			return (tmpVar != null) ? tmpVar : REASON.WRAPPER_UNKNOWN_VALUE;
		}
	}

	public enum FEATURE_TYPE {
		PTZ(0),
		WRAPPER_UNKNOWN_VALUE(Integer.MAX_VALUE);
		
		private final int value;
		
		FEATURE_TYPE(int value) {
			this.value = value;
		}

		public int toInt() {
			return value;
		}

		private static final SparseArrayCompat<FEATURE_TYPE> intToTypeMap = new SparseArrayCompat< FEATURE_TYPE>();
		
		static {
			for (FEATURE_TYPE type : FEATURE_TYPE.values()) {
				intToTypeMap.put(type.value, type);
			}
		}

		public static FEATURE_TYPE fromInt(int i) {
			FEATURE_TYPE tmpVar = intToTypeMap.get(i);
			return (tmpVar != null) ? tmpVar : FEATURE_TYPE.WRAPPER_UNKNOWN_VALUE;
		}
	}

	public enum PTZ_ACTION_TYPE {
		PTZActionType_Start(0),
		PTZActionType_Reset(1),
		PTZActionType_ZoomIn(2),
		PTZActionType_ZoomOut(4),
		PTZActionType_PanLeft(8),
		PTZActionType_PanRight(16),
		PTZActionType_TiltUp(32),
		PTZActionType_TiltDown(64),
		PTZActionType_End(128),
		WRAPPER_UNKNOWN_VALUE(Integer.MAX_VALUE);
		
		private final int value;
		
		PTZ_ACTION_TYPE(int value) {
			this.value = value;
		}

		public int toInt() {
			return value;
		}

		private static final SparseArrayCompat<PTZ_ACTION_TYPE> intToTypeMap = new SparseArrayCompat< PTZ_ACTION_TYPE>();
		
		static {
			for (PTZ_ACTION_TYPE type : PTZ_ACTION_TYPE.values()) {
				intToTypeMap.put(type.value, type);
			}
		}

		public static PTZ_ACTION_TYPE fromInt(int i) {
			PTZ_ACTION_TYPE tmpVar = intToTypeMap.get(i);
			return (tmpVar != null) ? tmpVar : PTZ_ACTION_TYPE.WRAPPER_UNKNOWN_VALUE;
		}
	}

	public enum PTZ_DEVICE_STATE {
		PTZState_Available(0),
		PTZState_Error(1),
		PTZState_Reset(2),
		PTZState_ZoomIn(4),
		PTZState_ZoomOut(8),
		PTZState_PanLeft(16),
		PTZState_PanRight(32),
		PTZState_TiltUp(64),
		PTZState_TiltDown(128),
		PTZState_End(256),
		WRAPPER_UNKNOWN_VALUE(Integer.MAX_VALUE);
		
		private final int value;
		
		PTZ_DEVICE_STATE(int value) {
			this.value = value;
		}

		public int toInt() {
			return value;
		}

		private static final SparseArrayCompat<PTZ_DEVICE_STATE> intToTypeMap = new SparseArrayCompat< PTZ_DEVICE_STATE>();
		
		static {
			for (PTZ_DEVICE_STATE type : PTZ_DEVICE_STATE.values()) {
				intToTypeMap.put(type.value, type);
			}
		}

		public static PTZ_DEVICE_STATE fromInt(int i) {
			PTZ_DEVICE_STATE tmpVar = intToTypeMap.get(i);
			return (tmpVar != null) ? tmpVar : PTZ_DEVICE_STATE.WRAPPER_UNKNOWN_VALUE;
		}
	}

	public int getIdProp();

	public String getCauseidProp();

	public RemoteControlSession.STATUS getStatusProp();

	public RemoteControlSession.FEATURE_TYPE getFeatureTypeProp();

	public RemoteControlSession.REASON getReasonProp();

	public String getSubreasonProp();

	public interface RemoteControlSessionIListener {
		void onControlSessionStatusChanged(RemoteControlSession sender, RemoteControlSession.STATUS status, RemoteControlSession.REASON reason);
		void onIncomingControlRequestCancelled(RemoteControlSession sender, String participantId);
		void onIncomingControlRequest(RemoteControlSession sender, String participantId);
		void onPTZDeviceControlCommand(RemoteControlSession sender, int ptzCommand);
		void onRemotePTZDeviceStateChanged(RemoteControlSession sender, int remotePTZDeviceState);
	}

	public void addListener(RemoteControlSessionIListener listener);

	public void removeListener(RemoteControlSessionIListener listener);

	
	public boolean acceptControlRequest();

	public boolean denyControlRequest();

	public boolean requestControl(String participantId);

	public boolean sendPTZCommand(int ptzCommand);

	public boolean sendPTZDeviceState(int ptzState);

	public boolean startRemoteControlSession();

	public void stopRemoteControlSession();

}

