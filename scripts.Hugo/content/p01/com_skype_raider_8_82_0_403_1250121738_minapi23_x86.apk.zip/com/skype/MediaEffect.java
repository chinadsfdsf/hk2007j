package com.skype;

public class MediaEffect {

    public static final int ME_Failed               = -1;
    public static final int ME_None                 = 0;
    public static final int ME_BlurDefault          = 1 << 0;
    public static final int ME_BlurLight            = 1 << 1;
    public static final int ME_BlurExperimental_1   = 1 << 2;
    public static final int ME_BlurExperimental_2   = 1 << 3;
    public static final int ME_BackgroundReplacement = 1 << 4;
    public static final int ME_WhiteboardZoom       = 1 << 5;
    public static final int ME_WhiteboardCleanup    = 1 << 6;
    public static final int ME_WhiteboardMotionDetection = 1 << 7;
    public static final int ME_WhiteboardZoomAndCleanup = ME_WhiteboardZoom | ME_WhiteboardCleanup;
    public static final int ME_WhiteboardCleanupAndMotion = ME_WhiteboardCleanup | ME_WhiteboardMotionDetection;
    public static final int ME_WhiteboardZoomAndCleanupAndMotion = ME_WhiteboardZoom | ME_WhiteboardCleanup | ME_WhiteboardMotionDetection;
    public static final int ME_Beautification       = 1 << 8;
};
