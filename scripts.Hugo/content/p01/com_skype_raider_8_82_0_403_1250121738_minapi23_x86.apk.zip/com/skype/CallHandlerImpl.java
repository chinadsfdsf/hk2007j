/* =============================================================================
 *                      GENERATED FILE - DO NOT MODIFY
 * =============================================================================
 * Copyright © Microsoft Corporation. All rights reserved.
 * 
 */
package com.skype;
import android.support.v4.util.SparseArrayCompat;
import java.util.Set;
import java.util.HashSet;
import java.lang.ref.ReferenceQueue;
import com.skype.NativeStringConvert;

import com.skype.CallHandler;

public class CallHandlerImpl extends ObjectInterfaceImpl implements CallHandler, ObjectInterface, NativeListenable {
	public CallHandlerImpl() {
		this(SkypeFactory.getInstance() );
	}

	public CallHandlerImpl(ObjectInterfaceFactory factory) {
		super(factory,factory.createCallHandler());
		factory.initializeListener(this);
	}

	static class CallHandlerWeakRef extends NativeWeakRef<ShutdownDestructible> {
		private ObjectInterfaceFactory factory;
		CallHandlerWeakRef(ObjectInterfaceFactory factory, ShutdownDestructible ref, ReferenceQueue<ShutdownDestructible> queue, long nativeObject) {
			super(ref, queue, nativeObject);
			this.factory = factory;
		}
		public void destroyNativeObject() {
			factory.destroyCallHandler(nativeObject);
		}
	}

	public NativeWeakRef<ShutdownDestructible> createNativeWeakRef(ObjectInterfaceFactory factory, ReferenceQueue<ShutdownDestructible> queue) {
		return new CallHandlerWeakRef(factory, this, queue, m_nativeObject);
	}

	public native void initializeListener();
	
	private final Set<CallHandlerIListener> m_listeners = new HashSet<CallHandlerIListener>();

	@Override
	public void addListener(CallHandlerIListener listener) {
		synchronized (m_listeners) {
			m_listeners.add(listener);
		}
	}

	@Override
	public void removeListener(CallHandlerIListener listener) {
		synchronized (m_listeners) {
			m_listeners.remove(listener);
		}
	}

	public void onActiveSpeakerListChanged(int callObjectId, byte[][] activeSpeakers) {
		synchronized (m_listeners) {
			for (CallHandlerIListener listener : m_listeners) {
				listener.onActiveSpeakerListChanged(this, callObjectId, NativeStringConvert.ConvertFromNativeStringArray(activeSpeakers));
			}
		}
	}

	public void onAudioStreamStateChanged(int callObjectId, CallHandler.MEDIA_DIRECTION direction, CallHandler.MEDIA_STREAM_STATE streamState) {
		synchronized (m_listeners) {
			for (CallHandlerIListener listener : m_listeners) {
				listener.onAudioStreamStateChanged(this, callObjectId, direction, streamState);
			}
		}
	}

	public void onCallHandlerOperationStatusChanged(CallHandler.CALL_HANDLER_OPERATION_TYPE callHandlerOperationType, byte[] causeId, int code, int subCode, byte[] phrase, byte[] result) {
		synchronized (m_listeners) {
			for (CallHandlerIListener listener : m_listeners) {
				listener.onCallHandlerOperationStatusChanged(this, callHandlerOperationType, NativeStringConvert.ConvertFromNativeBytes(causeId), code, subCode, NativeStringConvert.ConvertFromNativeBytes(phrase), NativeStringConvert.ConvertFromNativeBytes(result));
			}
		}
	}

	public void onCallMeBackOperationStatusChange(int callObjectId, byte[] participantMri, int failureReason, int code, int subCode, byte[] phrase, byte[] causeId) {
		synchronized (m_listeners) {
			for (CallHandlerIListener listener : m_listeners) {
				listener.onCallMeBackOperationStatusChange(this, callObjectId, NativeStringConvert.ConvertFromNativeBytes(participantMri), failureReason, code, subCode, NativeStringConvert.ConvertFromNativeBytes(phrase), NativeStringConvert.ConvertFromNativeBytes(causeId));
			}
		}
	}

	public void onCallTransferCallReceived(int callObjectId, int targetCallObjectId, byte[] transferorMri, byte[] transferTargetMri) {
		synchronized (m_listeners) {
			for (CallHandlerIListener listener : m_listeners) {
				listener.onCallTransferCallReceived(this, callObjectId, targetCallObjectId, NativeStringConvert.ConvertFromNativeBytes(transferorMri), NativeStringConvert.ConvertFromNativeBytes(transferTargetMri));
			}
		}
	}

	public void onDominantSpeakerListChanged(int callObjectId, byte[][] dominantSpeakers) {
		synchronized (m_listeners) {
			for (CallHandlerIListener listener : m_listeners) {
				listener.onDominantSpeakerListChanged(this, callObjectId, NativeStringConvert.ConvertFromNativeStringArray(dominantSpeakers));
			}
		}
	}

	public void onE2EEncryptionStatusChanged(int callObjectId, boolean enabled, byte[] fingerprintsJson, byte[] errorMessage) {
		synchronized (m_listeners) {
			for (CallHandlerIListener listener : m_listeners) {
				listener.onE2EEncryptionStatusChanged(this, callObjectId, enabled, NativeStringConvert.ConvertFromNativeBytes(fingerprintsJson), NativeStringConvert.ConvertFromNativeBytes(errorMessage));
			}
		}
	}

	public void onMediaNegotiationStatusChange(int callObjectId, CallHandler.MODALITY_TYPE modalityType, CallHandler.MEDIA_NEGOTIATION_STATUS_CODE mediaNegotiationStatusCode, byte[] causeId) {
		synchronized (m_listeners) {
			for (CallHandlerIListener listener : m_listeners) {
				listener.onMediaNegotiationStatusChange(this, callObjectId, modalityType, mediaNegotiationStatusCode, NativeStringConvert.ConvertFromNativeBytes(causeId));
			}
		}
	}

	public void onMuteParticipantsOperationStatusChanged(int callObjectId, byte[] causeId, int code, int subCode, byte[] phrase) {
		synchronized (m_listeners) {
			for (CallHandlerIListener listener : m_listeners) {
				listener.onMuteParticipantsOperationStatusChanged(this, callObjectId, NativeStringConvert.ConvertFromNativeBytes(causeId), code, subCode, NativeStringConvert.ConvertFromNativeBytes(phrase));
			}
		}
	}

	public void onMuteSelfOperationStatusChange(int callObjectId, byte[] transactionEnd) {
		synchronized (m_listeners) {
			for (CallHandlerIListener listener : m_listeners) {
				listener.onMuteSelfOperationStatusChange(this, callObjectId, NativeStringConvert.ConvertFromNativeBytes(transactionEnd));
			}
		}
	}

	public void onNudgeParticipantsOperationStatusChanged(int callObjectId, byte[] context, int failureReason) {
		synchronized (m_listeners) {
			for (CallHandlerIListener listener : m_listeners) {
				listener.onNudgeParticipantsOperationStatusChanged(this, callObjectId, NativeStringConvert.ConvertFromNativeBytes(context), failureReason);
			}
		}
	}

	public void onOperationStatusChanged(int callObjectId, byte[] result) {
		synchronized (m_listeners) {
			for (CallHandlerIListener listener : m_listeners) {
				listener.onOperationStatusChanged(this, callObjectId, NativeStringConvert.ConvertFromNativeBytes(result));
			}
		}
	}

	public void onProxiedPushNotification(int eventId, byte[] payload) {
		synchronized (m_listeners) {
			for (CallHandlerIListener listener : m_listeners) {
				listener.onProxiedPushNotification(this, eventId, NativeStringConvert.ConvertFromNativeBytes(payload));
			}
		}
	}

	public void onPublishStateOperationStatusChanged(int callObjectId, byte[] causeId, int code, int subCode, byte[] phrase, byte[] stateId, byte[] result) {
		synchronized (m_listeners) {
			for (CallHandlerIListener listener : m_listeners) {
				listener.onPublishStateOperationStatusChanged(this, callObjectId, NativeStringConvert.ConvertFromNativeBytes(causeId), code, subCode, NativeStringConvert.ConvertFromNativeBytes(phrase), NativeStringConvert.ConvertFromNativeBytes(stateId), NativeStringConvert.ConvertFromNativeBytes(result));
			}
		}
	}

	public void onRemoteUserEventsReceived(int callObjectId, byte[] participantId, byte[] events) {
		synchronized (m_listeners) {
			for (CallHandlerIListener listener : m_listeners) {
				listener.onRemoteUserEventsReceived(this, callObjectId, NativeStringConvert.ConvertFromNativeBytes(participantId), NativeStringConvert.ConvertFromNativeBytes(events));
			}
		}
	}

	public void onRemoteVideosCountChanged(int participantObjectId) {
		synchronized (m_listeners) {
			for (CallHandlerIListener listener : m_listeners) {
				listener.onRemoteVideosCountChanged(this, participantObjectId);
			}
		}
	}

	public void onRemoveStateOperationStatusChanged(int callObjectId, byte[] causeId, boolean operationSuccess, byte[] result, int code, int subCode, byte[] phrase) {
		synchronized (m_listeners) {
			for (CallHandlerIListener listener : m_listeners) {
				listener.onRemoveStateOperationStatusChanged(this, callObjectId, NativeStringConvert.ConvertFromNativeBytes(causeId), operationSuccess, NativeStringConvert.ConvertFromNativeBytes(result), code, subCode, NativeStringConvert.ConvertFromNativeBytes(phrase));
			}
		}
	}

	public void onSlowedDownActiveTalkerListChanged(int callObjectId, byte[][] slowedDownActiveSpeakers) {
		synchronized (m_listeners) {
			for (CallHandlerIListener listener : m_listeners) {
				listener.onSlowedDownActiveTalkerListChanged(this, callObjectId, NativeStringConvert.ConvertFromNativeStringArray(slowedDownActiveSpeakers));
			}
		}
	}

	public void onUnmuteSelfOperationStatusChange(int callObjectId, CallHandler.OPERATIONRESULTCODE operationResult, int failureReason, byte[] transactionEnd) {
		synchronized (m_listeners) {
			for (CallHandlerIListener listener : m_listeners) {
				listener.onUnmuteSelfOperationStatusChange(this, callObjectId, operationResult, failureReason, NativeStringConvert.ConvertFromNativeBytes(transactionEnd));
			}
		}
	}

	public void onUpdateMeetingRolesOperationStatusChanged(int callObjectId, byte[] causeId, int code, int subCode, byte[] phrase) {
		synchronized (m_listeners) {
			for (CallHandlerIListener listener : m_listeners) {
				listener.onUpdateMeetingRolesOperationStatusChanged(this, callObjectId, NativeStringConvert.ConvertFromNativeBytes(causeId), code, subCode, NativeStringConvert.ConvertFromNativeBytes(phrase));
			}
		}
	}

	@Override
	public boolean addBroadcastModality(int callObjectId, String broadcastContext, String causeId) {
		return addBroadcastModality(callObjectId, NativeStringConvert.ConvertToNativeBytes(broadcastContext), NativeStringConvert.ConvertToNativeBytes(causeId));
	}

	private native boolean addBroadcastModality(int callObjectId, byte[] broadcastContext, byte[] causeId);
	@Override
	public native boolean addGroupModality(int callObjectId, int additionalParametersObjectId);

	@Override
	public int addParticipant(int callObjectId, String participant, String threadId, String messageId, String additionalData) {
		return addParticipant(callObjectId, NativeStringConvert.ConvertToNativeBytes(participant), NativeStringConvert.ConvertToNativeBytes(threadId), NativeStringConvert.ConvertToNativeBytes(messageId), NativeStringConvert.ConvertToNativeBytes(additionalData));
	}

	private native int addParticipant(int callObjectId, byte[] participant, byte[] threadId, byte[] messageId, byte[] additionalData);
	@Override
	public int addParticipant(int callObjectId, String participant) {
		return addParticipant(callObjectId, participant, "", "", "");
	}
	@Override
	public int addParticipant(int callObjectId, String participant, String threadId) {
		return addParticipant(callObjectId, participant, threadId, "", "");
	}
	@Override
	public int addParticipant(int callObjectId, String participant, String threadId, String messageId) {
		return addParticipant(callObjectId, participant, threadId, messageId, "");
	}
	@Override
	public int addParticipantToCall(int callObjectId, String participant, int additionalParametersObjectId) {
		return addParticipantToCall(callObjectId, NativeStringConvert.ConvertToNativeBytes(participant), additionalParametersObjectId);
	}

	private native int addParticipantToCall(int callObjectId, byte[] participant, int additionalParametersObjectId);
	@Override
	public AddParticipantsToCall_Result addParticipantsToCall(int callObjectId, String[] participantList, int additionalParametersObjectId) {
		return addParticipantsToCall(callObjectId, NativeStringConvert.ConvertArrToNativeByteArr(participantList), additionalParametersObjectId);
	}

	private native AddParticipantsToCall_Result addParticipantsToCall(int callObjectId, byte[][] participantList, int additionalParametersObjectId);
	@Override
	public boolean admit(int callObjectId, String causeId, int admitParametersObjId) {
		return admit(callObjectId, NativeStringConvert.ConvertToNativeBytes(causeId), admitParametersObjId);
	}

	private native boolean admit(int callObjectId, byte[] causeId, int admitParametersObjId);
	@Override
	public void admitParticipants(int callObjectId, String[] participantList, String causeId) {
		admitParticipants(callObjectId, NativeStringConvert.ConvertArrToNativeByteArr(participantList), NativeStringConvert.ConvertToNativeBytes(causeId));
	}

	private native void admitParticipants(int callObjectId, byte[][] participantList, byte[] causeId);
	@Override
	public void admitParticipants(int callObjectId, String[] participantList) {
		admitParticipants(callObjectId, participantList, "");
	}
	@Override
	public native boolean answer(int callObjectId, int answerParametersObjectId);

	@Override
	public boolean answerCall(int callObjectId, boolean isVideoEnabled, String endpointBehaviors) {
		return answerCall(callObjectId, isVideoEnabled, NativeStringConvert.ConvertToNativeBytes(endpointBehaviors));
	}

	private native boolean answerCall(int callObjectId, boolean isVideoEnabled, byte[] endpointBehaviors);
	@Override
	public boolean answerCall(int callObjectId) {
		return answerCall(callObjectId, false, "");
	}
	@Override
	public boolean answerCall(int callObjectId, boolean isVideoEnabled) {
		return answerCall(callObjectId, isVideoEnabled, "");
	}
	@Override
	public boolean callAnswer(int callObjectId, CallHandler.ANSWER_MEDIA_TYPE answerType, String endpointBehaviors, int clientEndpointCapabilities, int muteFlags) {
		return callAnswer(callObjectId, answerType, NativeStringConvert.ConvertToNativeBytes(endpointBehaviors), clientEndpointCapabilities, muteFlags);
	}

	private native boolean callAnswer(int callObjectId, CallHandler.ANSWER_MEDIA_TYPE answerType, byte[] endpointBehaviors, int clientEndpointCapabilities, int muteFlags);
	@Override
	public boolean callAnswer(int callObjectId, CallHandler.ANSWER_MEDIA_TYPE answerType) {
		return callAnswer(callObjectId, answerType, "", 0, 0);
	}
	@Override
	public boolean callAnswer(int callObjectId, CallHandler.ANSWER_MEDIA_TYPE answerType, String endpointBehaviors) {
		return callAnswer(callObjectId, answerType, endpointBehaviors, 0, 0);
	}
	@Override
	public boolean callAnswer(int callObjectId, CallHandler.ANSWER_MEDIA_TYPE answerType, String endpointBehaviors, int clientEndpointCapabilities) {
		return callAnswer(callObjectId, answerType, endpointBehaviors, clientEndpointCapabilities, 0);
	}
	@Override
	public boolean callAssimilate(int callObjectId1, int callObjectId2, String threadId, String messageId) {
		return callAssimilate(callObjectId1, callObjectId2, NativeStringConvert.ConvertToNativeBytes(threadId), NativeStringConvert.ConvertToNativeBytes(messageId));
	}

	private native boolean callAssimilate(int callObjectId1, int callObjectId2, byte[] threadId, byte[] messageId);
	@Override
	public boolean callAssimilate(int callObjectId1, int callObjectId2) {
		return callAssimilate(callObjectId1, callObjectId2, "", "");
	}
	@Override
	public boolean callAssimilate(int callObjectId1, int callObjectId2, String threadId) {
		return callAssimilate(callObjectId1, callObjectId2, threadId, "");
	}
	@Override
	public native boolean callAttachSendVideo(int callObjectId, int videoObjectId);

	@Override
	public native boolean callEnableDTMFTonesCapture(int callObjectId, boolean enable);

	@Override
	public native CallGetDTMFTones_Result callGetDTMFTones(int callObjectId);

	@Override
	public native CallGetParticipantVideos_Result callGetParticipantVideos(int callParticipantObjectId);

	@Override
	public native CallGetParticipants_Result callGetParticipants(int callObjectId);

	@Override
	public native CallGetSendVideos_Result callGetSendVideos(int callObjectId);

	@Override
	public String callGetTechnicalInformationJson(int callObjectId) {
		return NativeStringConvert.ConvertFromNativeBytes(callGetTechnicalInformationJsonNativeString(callObjectId));
	}

	private native byte[] callGetTechnicalInformationJsonNativeString(int callObjectId);
	@Override
	public boolean callHold(int callObjectId, boolean hold, String negotiationTag, int holdUnholdParametersObjId) {
		return callHold(callObjectId, hold, NativeStringConvert.ConvertToNativeBytes(negotiationTag), holdUnholdParametersObjId);
	}

	private native boolean callHold(int callObjectId, boolean hold, byte[] negotiationTag, int holdUnholdParametersObjId);
	@Override
	public boolean callHold(int callObjectId, boolean hold) {
		return callHold(callObjectId, hold, "", 0);
	}
	@Override
	public boolean callHold(int callObjectId, boolean hold, String negotiationTag) {
		return callHold(callObjectId, hold, negotiationTag, 0);
	}
	@Override
	public boolean callMeBack(int callObjectId, String participantMri, String assertedId, String causeId) {
		return callMeBack(callObjectId, NativeStringConvert.ConvertToNativeBytes(participantMri), NativeStringConvert.ConvertToNativeBytes(assertedId), NativeStringConvert.ConvertToNativeBytes(causeId));
	}

	private native boolean callMeBack(int callObjectId, byte[] participantMri, byte[] assertedId, byte[] causeId);
	@Override
	public boolean callMeBack(int callObjectId, String participantMri, String assertedId) {
		return callMeBack(callObjectId, participantMri, assertedId, "");
	}
	@Override
	public boolean callMerge(int callObjectId1, int callObjectId2, String threadId, String messageId, String causeId, String additionalData) {
		return callMerge(callObjectId1, callObjectId2, NativeStringConvert.ConvertToNativeBytes(threadId), NativeStringConvert.ConvertToNativeBytes(messageId), NativeStringConvert.ConvertToNativeBytes(causeId), NativeStringConvert.ConvertToNativeBytes(additionalData));
	}

	private native boolean callMerge(int callObjectId1, int callObjectId2, byte[] threadId, byte[] messageId, byte[] causeId, byte[] additionalData);
	@Override
	public boolean callMerge(int callObjectId1, int callObjectId2) {
		return callMerge(callObjectId1, callObjectId2, "", "", "", "");
	}
	@Override
	public boolean callMerge(int callObjectId1, int callObjectId2, String threadId) {
		return callMerge(callObjectId1, callObjectId2, threadId, "", "", "");
	}
	@Override
	public boolean callMerge(int callObjectId1, int callObjectId2, String threadId, String messageId) {
		return callMerge(callObjectId1, callObjectId2, threadId, messageId, "", "");
	}
	@Override
	public boolean callMerge(int callObjectId1, int callObjectId2, String threadId, String messageId, String causeId) {
		return callMerge(callObjectId1, callObjectId2, threadId, messageId, causeId, "");
	}
	@Override
	public native boolean callMute(int callObjectId, boolean mute);

	@Override
	public void callMuteParticipants(int callObjectId, CallHandler.MUTE_SCOPE muteScope, String[] participantList, String causeId) {
		callMuteParticipants(callObjectId, muteScope, NativeStringConvert.ConvertArrToNativeByteArr(participantList), NativeStringConvert.ConvertToNativeBytes(causeId));
	}

	private native void callMuteParticipants(int callObjectId, CallHandler.MUTE_SCOPE muteScope, byte[][] participantList, byte[] causeId);
	@Override
	public void callMuteParticipants(int callObjectId, CallHandler.MUTE_SCOPE muteScope, String[] participantList) {
		callMuteParticipants(callObjectId, muteScope, participantList, "");
	}
	@Override
	public native boolean callMuteSpeaker(int callObjectId, boolean mute);

	@Override
	public native int callParticipantGetCallObject(int callParticipantObjectId);

	@Override
	public native boolean callSendDtmf(int callObjectId, CallHandler.DTMF dtmfTone);

	@Override
	public native boolean callSetAudioMidcallConfig(int callObjectId, CallHandler.AUDIO_CONFIG audioConfig, int mode);

	@Override
	public boolean callSetAudioMidcallConfigJson(int callObjectId, String audioConfigJson) {
		return callSetAudioMidcallConfigJson(callObjectId, NativeStringConvert.ConvertToNativeBytes(audioConfigJson));
	}

	private native boolean callSetAudioMidcallConfigJson(int callObjectId, byte[] audioConfigJson);
	@Override
	public native boolean callSetAudioUsageMode(int callObjectId, CallHandler.AUDIO_USAGE_MODE audioUsageMode);

	@Override
	public boolean callSetMaxVideoChannels(int callObjectId, int maxVideoChannels, String negotiationTag, String causeId) {
		return callSetMaxVideoChannels(callObjectId, maxVideoChannels, NativeStringConvert.ConvertToNativeBytes(negotiationTag), NativeStringConvert.ConvertToNativeBytes(causeId));
	}

	private native boolean callSetMaxVideoChannels(int callObjectId, int maxVideoChannels, byte[] negotiationTag, byte[] causeId);
	@Override
	public boolean callSetMaxVideoChannels(int callObjectId, int maxVideoChannels, String negotiationTag) {
		return callSetMaxVideoChannels(callObjectId, maxVideoChannels, negotiationTag, "");
	}
	@Override
	public native boolean callShareSystemSound(int callObjectId, boolean enable);

	@Override
	public boolean callStartAudio(int callObjectId, String negotiationTag) {
		return callStartAudio(callObjectId, NativeStringConvert.ConvertToNativeBytes(negotiationTag));
	}

	private native boolean callStartAudio(int callObjectId, byte[] negotiationTag);
	@Override
	public boolean callStartAudio(int callObjectId) {
		return callStartAudio(callObjectId, "");
	}
	@Override
	public boolean callStopAudio(int callObjectId, String negotiationTag) {
		return callStopAudio(callObjectId, NativeStringConvert.ConvertToNativeBytes(negotiationTag));
	}

	private native boolean callStopAudio(int callObjectId, byte[] negotiationTag);
	@Override
	public boolean callStopAudio(int callObjectId) {
		return callStopAudio(callObjectId, "");
	}
	@Override
	public boolean callUpdateEndpointMetaData(int callObjectId, String endpointMetaData) {
		return callUpdateEndpointMetaData(callObjectId, NativeStringConvert.ConvertToNativeBytes(endpointMetaData));
	}

	private native boolean callUpdateEndpointMetaData(int callObjectId, byte[] endpointMetaData);
	@Override
	public boolean callUpdateEndpointMetaData(int callObjectId) {
		return callUpdateEndpointMetaData(callObjectId, "");
	}
	@Override
	public native void consultativeTransferWithOptions(int transfereeCallObjectId, int transferParametersObjectId, int transferOptionsObjId);

	@Override
	public void consultativeTransferWithOptions(int transfereeCallObjectId, int transferParametersObjectId) {
		consultativeTransferWithOptions(transfereeCallObjectId, transferParametersObjectId, 0);
	}
	@Override
	public native boolean createAddGroupModalityParameters(AddGroupModalityParameters addGroupModalityParameters);

	@Override
	public native boolean createAddParticipantParameters(AddParticipantParameters addParticipantParameters);

	@Override
	public native boolean createAdmitParameters(AdmitParameters admitParameters);

	@Override
	public native boolean createAnswerParameters(AnswerParameters createAnswerParameters);

	@Override
	public native boolean createCallStateParameters(CallStateParameters callStateParameters);

	@Override
	public int createContentSharing(int callObjectId, String contentSharingGuid, String contentSharingIdentity, String subject, String initialContentSharingSessionState) {
		return createContentSharing(callObjectId, NativeStringConvert.ConvertToNativeBytes(contentSharingGuid), NativeStringConvert.ConvertToNativeBytes(contentSharingIdentity), NativeStringConvert.ConvertToNativeBytes(subject), NativeStringConvert.ConvertToNativeBytes(initialContentSharingSessionState));
	}

	private native int createContentSharing(int callObjectId, byte[] contentSharingGuid, byte[] contentSharingIdentity, byte[] subject, byte[] initialContentSharingSessionState);
	@Override
	public int createContentSharing(int callObjectId, String contentSharingGuid, String contentSharingIdentity) {
		return createContentSharing(callObjectId, contentSharingGuid, contentSharingIdentity, "", "");
	}
	@Override
	public int createContentSharing(int callObjectId, String contentSharingGuid, String contentSharingIdentity, String subject) {
		return createContentSharing(callObjectId, contentSharingGuid, contentSharingIdentity, subject, "");
	}
	@Override
	public native boolean createHoldUnholdParameters(HoldUnholdParameters holdUnholdParameters);

	@Override
	public native boolean createJoinMeetingGroupParameters(JoinMeetingGroupParameters joinMeetingGroupParameters);

	@Override
	public native boolean createLeaveMeetingGroupParameters(LeaveMeetingGroupParameters leaveMeetingGroupParameters);

	@Override
	public native boolean createMediaStateConfiguration(MediaStateConfiguration mediaStateConfiguration);

	@Override
	public native boolean createMeetingSettingsParameters(MeetingSettingsParameters meetingSettingsParameters);

	@Override
	public native boolean createMergeParameters(MergeParameters mergeParameters);

	@Override
	public native boolean createParkUnparkParameters(ParkUnparkParameters parkUnparkParameters);

	@Override
	public native boolean createRedirectOptions(RedirectOptions redirectOptions);

	@Override
	public int createRemoteControlSession(int callObjectId, int masterSourceDeviceId, int masterSinkDeviceId, String remoteControlSessionCauseId, RemoteControlSession.FEATURE_TYPE remoteControlSessionType) {
		return createRemoteControlSession(callObjectId, masterSourceDeviceId, masterSinkDeviceId, NativeStringConvert.ConvertToNativeBytes(remoteControlSessionCauseId), remoteControlSessionType);
	}

	private native int createRemoteControlSession(int callObjectId, int masterSourceDeviceId, int masterSinkDeviceId, byte[] remoteControlSessionCauseId, RemoteControlSession.FEATURE_TYPE remoteControlSessionType);
	@Override
	public native boolean createSafeTransferParameters(SafeTransferParameters safeTransferParameters);

	@Override
	public native boolean createSearchOptionsParameters(SearchOptionsParameters searchOptionsParameters);

	@Override
	public native boolean createSessionParameters(SessionParameters sessionParameters);

	@Override
	public native boolean createSetMeetingLayoutParameters(SetMeetingLayoutParameters setMeetingLayoutParameters);

	@Override
	public native boolean createStopParameters(StopParameters createStopParameters);

	@Override
	public native boolean createTransferParameters(TransferParameters transferParameters);

	@Override
	public native boolean createUpdateMeetingGroupParameters(UpdateMeetingGroupParameters updateMeetingGroupParameters);

	@Override
	public native boolean createUpdateMeetingLiveStateParameters(UpdateMeetingLiveStateParameters updateMeetingLiveStateParameters);

	@Override
	public native boolean createUpdateParticipantInterpretationStateParameters(UpdateParticipantInterpretationStateParameters updateParticipantInterpretationStateParameters);

	@Override
	public native boolean endCallForAll(int callObjectId, int stopParametersObjId);

	@Override
	public boolean endCallForAll(int callObjectId) {
		return endCallForAll(callObjectId, 0);
	}
	@Override
	public native GetActiveCalls_Result getActiveCalls();

	@Override
	public native boolean getAddGroupModalityParameters(int inMemObjId, AddGroupModalityParameters addGroupModalityParameters);

	@Override
	public native boolean getAddParticipantParameters(int inMemObjId, AddParticipantParameters addParticipantParameters);

	@Override
	public native boolean getAdmitParameters(int inMemObjId, AdmitParameters admitParameters);

	@Override
	public boolean getAllParticipants(int callObjectId, String scope, String causeId) {
		return getAllParticipants(callObjectId, NativeStringConvert.ConvertToNativeBytes(scope), NativeStringConvert.ConvertToNativeBytes(causeId));
	}

	private native boolean getAllParticipants(int callObjectId, byte[] scope, byte[] causeId);
	@Override
	public native boolean getAnswerParameters(int inMemObjId, AnswerParameters answerParameters);

	@Override
	public String getCallEndDiagnosticCode(int callObjectId) {
		return NativeStringConvert.ConvertFromNativeBytes(getCallEndDiagnosticCodeNativeString(callObjectId));
	}

	private native byte[] getCallEndDiagnosticCodeNativeString(int callObjectId);
	@Override
	public native boolean getCallStateParameters(int inMemObjId, CallStateParameters callStateParameters);

	@Override
	public boolean getCallState(String causeId, int getCallParametersObjId) {
		return getCallState(NativeStringConvert.ConvertToNativeBytes(causeId), getCallParametersObjId);
	}

	private native boolean getCallState(byte[] causeId, int getCallParametersObjId);
	@Override
	public native GetContentSharingSessions_Result getContentSharingSessions(int callObjectId);

	@Override
	public String getDebugInformation(String command) {
		return NativeStringConvert.ConvertFromNativeBytes(getDebugInformationNativeString(NativeStringConvert.ConvertToNativeBytes(command)));
	}

	private native byte[] getDebugInformationNativeString(byte[] command);
	@Override
	public native boolean getHoldUnholdParameters(int inMemObjId, HoldUnholdParameters holdUnholdParameters);

	@Override
	public native int getIntegerProperty(int objectId, PROPKEY propKey);

	@Override
	public String getJoinBlob(int callObjectId) {
		return NativeStringConvert.ConvertFromNativeBytes(getJoinBlobNativeString(callObjectId));
	}

	private native byte[] getJoinBlobNativeString(int callObjectId);
	@Override
	public native boolean getJoinMeetingGroupParameters(int inMemObjId, JoinMeetingGroupParameters joinMeetingGroupParameters);

	@Override
	public native boolean getLeaveMeetingGroupParameters(int inMemObjId, LeaveMeetingGroupParameters leaveMeetingGroupParameters);

	@Override
	public native boolean getMediaStateConfiguration(int inMemObjId, MediaStateConfiguration mediaStateConfiguration);

	@Override
	public native boolean getMergeParameters(int inMemObjId, MergeParameters mergeParameters);

	@Override
	public native boolean getParkUnparkParameters(int inMemObjId, ParkUnparkParameters parkUnparkParameters);

	@Override
	public native boolean getRedirectOptions(int inMemObjId, RedirectOptions redirectOptions);

	@Override
	public native boolean getSafeTransferParameters(int inMemObjId, SafeTransferParameters safeTransferParameters);

	@Override
	public native boolean getSessionParameters(int inMemObjId, SessionParameters sessionParameters);

	@Override
	public native boolean getSetMeetingLayoutParameters(int inMemObjId, SetMeetingLayoutParameters setMeetingLayoutParameters);

	@Override
	public native boolean getStopParameters(int inMemObjId, StopParameters stopParameters);

	@Override
	public String getStringProperty(int objectId, PROPKEY propKey) {
		return NativeStringConvert.ConvertFromNativeBytes(getStringPropertyNativeString(objectId, propKey));
	}

	private native byte[] getStringPropertyNativeString(int objectId, PROPKEY propKey);
	@Override
	public native boolean getTransferParameters(int inMemObjId, TransferParameters transferParameters);

	@Override
	public native boolean getUpdateMeetingGroupParameters(int inMemObjId, UpdateMeetingGroupParameters updateMeetingGroupParameters);

	@Override
	public native boolean getUpdateMeetingLiveStateParameters(int inMemObjId, UpdateMeetingLiveStateParameters updateMeetingLiveStateParameters);

	@Override
	public native boolean getUpdateParticipantInterpretationStateParameters(int inMemObjId, UpdateParticipantInterpretationStateParameters updateParticipantInterpretationStateParameters);

	@Override
	public int joinCall(String joinContext, CallHandler.MEDIA_PEER_TYPE mediaPeerType, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration, String threadId, String messageId, String subject, String conversationType, String meetingInfo, String endpointMetaData, String onBehalfOf, String broadcastContext) {
		return joinCall(NativeStringConvert.ConvertToNativeBytes(joinContext), mediaPeerType, isVideoEnabled, isGoLive, allowHostless, enableGroupCallMeetupGeneration, NativeStringConvert.ConvertToNativeBytes(threadId), NativeStringConvert.ConvertToNativeBytes(messageId), NativeStringConvert.ConvertToNativeBytes(subject), NativeStringConvert.ConvertToNativeBytes(conversationType), NativeStringConvert.ConvertToNativeBytes(meetingInfo), NativeStringConvert.ConvertToNativeBytes(endpointMetaData), NativeStringConvert.ConvertToNativeBytes(onBehalfOf), NativeStringConvert.ConvertToNativeBytes(broadcastContext));
	}

	private native int joinCall(byte[] joinContext, CallHandler.MEDIA_PEER_TYPE mediaPeerType, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration, byte[] threadId, byte[] messageId, byte[] subject, byte[] conversationType, byte[] meetingInfo, byte[] endpointMetaData, byte[] onBehalfOf, byte[] broadcastContext);
	@Override
	public int joinCall(String joinContext, CallHandler.MEDIA_PEER_TYPE mediaPeerType) {
		return joinCall(joinContext, mediaPeerType, false, false, true, false, "", "", "", "", "", "", "", "");
	}
	@Override
	public int joinCall(String joinContext, CallHandler.MEDIA_PEER_TYPE mediaPeerType, boolean isVideoEnabled) {
		return joinCall(joinContext, mediaPeerType, isVideoEnabled, false, true, false, "", "", "", "", "", "", "", "");
	}
	@Override
	public int joinCall(String joinContext, CallHandler.MEDIA_PEER_TYPE mediaPeerType, boolean isVideoEnabled, boolean isGoLive) {
		return joinCall(joinContext, mediaPeerType, isVideoEnabled, isGoLive, true, false, "", "", "", "", "", "", "", "");
	}
	@Override
	public int joinCall(String joinContext, CallHandler.MEDIA_PEER_TYPE mediaPeerType, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless) {
		return joinCall(joinContext, mediaPeerType, isVideoEnabled, isGoLive, allowHostless, false, "", "", "", "", "", "", "", "");
	}
	@Override
	public int joinCall(String joinContext, CallHandler.MEDIA_PEER_TYPE mediaPeerType, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration) {
		return joinCall(joinContext, mediaPeerType, isVideoEnabled, isGoLive, allowHostless, enableGroupCallMeetupGeneration, "", "", "", "", "", "", "", "");
	}
	@Override
	public int joinCall(String joinContext, CallHandler.MEDIA_PEER_TYPE mediaPeerType, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration, String threadId) {
		return joinCall(joinContext, mediaPeerType, isVideoEnabled, isGoLive, allowHostless, enableGroupCallMeetupGeneration, threadId, "", "", "", "", "", "", "");
	}
	@Override
	public int joinCall(String joinContext, CallHandler.MEDIA_PEER_TYPE mediaPeerType, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration, String threadId, String messageId) {
		return joinCall(joinContext, mediaPeerType, isVideoEnabled, isGoLive, allowHostless, enableGroupCallMeetupGeneration, threadId, messageId, "", "", "", "", "", "");
	}
	@Override
	public int joinCall(String joinContext, CallHandler.MEDIA_PEER_TYPE mediaPeerType, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration, String threadId, String messageId, String subject) {
		return joinCall(joinContext, mediaPeerType, isVideoEnabled, isGoLive, allowHostless, enableGroupCallMeetupGeneration, threadId, messageId, subject, "", "", "", "", "");
	}
	@Override
	public int joinCall(String joinContext, CallHandler.MEDIA_PEER_TYPE mediaPeerType, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration, String threadId, String messageId, String subject, String conversationType) {
		return joinCall(joinContext, mediaPeerType, isVideoEnabled, isGoLive, allowHostless, enableGroupCallMeetupGeneration, threadId, messageId, subject, conversationType, "", "", "", "");
	}
	@Override
	public int joinCall(String joinContext, CallHandler.MEDIA_PEER_TYPE mediaPeerType, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration, String threadId, String messageId, String subject, String conversationType, String meetingInfo) {
		return joinCall(joinContext, mediaPeerType, isVideoEnabled, isGoLive, allowHostless, enableGroupCallMeetupGeneration, threadId, messageId, subject, conversationType, meetingInfo, "", "", "");
	}
	@Override
	public int joinCall(String joinContext, CallHandler.MEDIA_PEER_TYPE mediaPeerType, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration, String threadId, String messageId, String subject, String conversationType, String meetingInfo, String endpointMetaData) {
		return joinCall(joinContext, mediaPeerType, isVideoEnabled, isGoLive, allowHostless, enableGroupCallMeetupGeneration, threadId, messageId, subject, conversationType, meetingInfo, endpointMetaData, "", "");
	}
	@Override
	public int joinCall(String joinContext, CallHandler.MEDIA_PEER_TYPE mediaPeerType, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration, String threadId, String messageId, String subject, String conversationType, String meetingInfo, String endpointMetaData, String onBehalfOf) {
		return joinCall(joinContext, mediaPeerType, isVideoEnabled, isGoLive, allowHostless, enableGroupCallMeetupGeneration, threadId, messageId, subject, conversationType, meetingInfo, endpointMetaData, onBehalfOf, "");
	}
	@Override
	public boolean joinMeetingGroup(int callObjectId, String causeId, int joinMeetingGroupParametersObjectId) {
		return joinMeetingGroup(callObjectId, NativeStringConvert.ConvertToNativeBytes(causeId), joinMeetingGroupParametersObjectId);
	}

	private native boolean joinMeetingGroup(int callObjectId, byte[] causeId, int joinMeetingGroupParametersObjectId);
	@Override
	public boolean joinPreheatedCall(int callObjectId, String causeId, int muteFlags) {
		return joinPreheatedCall(callObjectId, NativeStringConvert.ConvertToNativeBytes(causeId), muteFlags);
	}

	private native boolean joinPreheatedCall(int callObjectId, byte[] causeId, int muteFlags);
	@Override
	public boolean joinPreheatedCall(int callObjectId) {
		return joinPreheatedCall(callObjectId, "", 0);
	}
	@Override
	public boolean joinPreheatedCall(int callObjectId, String causeId) {
		return joinPreheatedCall(callObjectId, causeId, 0);
	}
	@Override
	public int joinSignalingSessionWithMeetingData(String meetingData, String resurrectPreference, String joinContext, CallHandler.MEDIA_PEER_TYPE mediaPeerType, int sessionParametersObjectId) {
		return joinSignalingSessionWithMeetingData(NativeStringConvert.ConvertToNativeBytes(meetingData), NativeStringConvert.ConvertToNativeBytes(resurrectPreference), NativeStringConvert.ConvertToNativeBytes(joinContext), mediaPeerType, sessionParametersObjectId);
	}

	private native int joinSignalingSessionWithMeetingData(byte[] meetingData, byte[] resurrectPreference, byte[] joinContext, CallHandler.MEDIA_PEER_TYPE mediaPeerType, int sessionParametersObjectId);
	@Override
	public int joinSignalingSession(String joinContext, CallHandler.MEDIA_PEER_TYPE mediaPeerType, int sessionParametersObjectId) {
		return joinSignalingSession(NativeStringConvert.ConvertToNativeBytes(joinContext), mediaPeerType, sessionParametersObjectId);
	}

	private native int joinSignalingSession(byte[] joinContext, CallHandler.MEDIA_PEER_TYPE mediaPeerType, int sessionParametersObjectId);
	@Override
	public native void leaveCall(int callObjectId, int stopParametersObjId);

	@Override
	public void leaveCall(int callObjectId) {
		leaveCall(callObjectId, 0);
	}
	@Override
	public boolean leaveMeetingGroup(int callObjectId, String causeId, int leaveMeetingGroupParametersObjectId) {
		return leaveMeetingGroup(callObjectId, NativeStringConvert.ConvertToNativeBytes(causeId), leaveMeetingGroupParametersObjectId);
	}

	private native boolean leaveMeetingGroup(int callObjectId, byte[] causeId, int leaveMeetingGroupParametersObjectId);
	@Override
	public void mergeCallParticipantLegs(int callObjectId, int mergeCallObjectId, String participantLegIdsJson, int mergeParametersObjectId) {
		mergeCallParticipantLegs(callObjectId, mergeCallObjectId, NativeStringConvert.ConvertToNativeBytes(participantLegIdsJson), mergeParametersObjectId);
	}

	private native void mergeCallParticipantLegs(int callObjectId, int mergeCallObjectId, byte[] participantLegIdsJson, int mergeParametersObjectId);
	@Override
	public void mergeCallParticipants(int callObjectId, int mergeCallObjectId, String[] participantIds, int mergeParametersObjectId) {
		mergeCallParticipants(callObjectId, mergeCallObjectId, NativeStringConvert.ConvertArrToNativeByteArr(participantIds), mergeParametersObjectId);
	}

	private native void mergeCallParticipants(int callObjectId, int mergeCallObjectId, byte[][] participantIds, int mergeParametersObjectId);
	@Override
	public void mergeCallWithPickupCode(int callObjectId, String pickupCode, int mergeParametersObjectId) {
		mergeCallWithPickupCode(callObjectId, NativeStringConvert.ConvertToNativeBytes(pickupCode), mergeParametersObjectId);
	}

	private native void mergeCallWithPickupCode(int callObjectId, byte[] pickupCode, int mergeParametersObjectId);
	@Override
	public boolean nudgeParticipants(int callObjectId, int additionalParametersObjectId, String[] participantList, String context) {
		return nudgeParticipants(callObjectId, additionalParametersObjectId, NativeStringConvert.ConvertArrToNativeByteArr(participantList), NativeStringConvert.ConvertToNativeBytes(context));
	}

	private native boolean nudgeParticipants(int callObjectId, int additionalParametersObjectId, byte[][] participantList, byte[] context);
	@Override
	public boolean nudgeParticipants(int callObjectId, int additionalParametersObjectId) {
		return nudgeParticipants(callObjectId, additionalParametersObjectId, null, "");
	}
	@Override
	public boolean nudgeParticipants(int callObjectId, int additionalParametersObjectId, String[] participantList) {
		return nudgeParticipants(callObjectId, additionalParametersObjectId, participantList, "");
	}
	@Override
	public int placeCallToVoicemail(String callGuid, CallHandler.MEDIA_PEER_TYPE mediaPeerType, String participant, String threadId, String voicemailResourcePath, String voicemailItemId) {
		return placeCallToVoicemail(NativeStringConvert.ConvertToNativeBytes(callGuid), mediaPeerType, NativeStringConvert.ConvertToNativeBytes(participant), NativeStringConvert.ConvertToNativeBytes(threadId), NativeStringConvert.ConvertToNativeBytes(voicemailResourcePath), NativeStringConvert.ConvertToNativeBytes(voicemailItemId));
	}

	private native int placeCallToVoicemail(byte[] callGuid, CallHandler.MEDIA_PEER_TYPE mediaPeerType, byte[] participant, byte[] threadId, byte[] voicemailResourcePath, byte[] voicemailItemId);
	@Override
	public int placeCallToVoicemail(String callGuid, CallHandler.MEDIA_PEER_TYPE mediaPeerType) {
		return placeCallToVoicemail(callGuid, mediaPeerType, "", "", "", "");
	}
	@Override
	public int placeCallToVoicemail(String callGuid, CallHandler.MEDIA_PEER_TYPE mediaPeerType, String participant) {
		return placeCallToVoicemail(callGuid, mediaPeerType, participant, "", "", "");
	}
	@Override
	public int placeCallToVoicemail(String callGuid, CallHandler.MEDIA_PEER_TYPE mediaPeerType, String participant, String threadId) {
		return placeCallToVoicemail(callGuid, mediaPeerType, participant, threadId, "", "");
	}
	@Override
	public int placeCallToVoicemail(String callGuid, CallHandler.MEDIA_PEER_TYPE mediaPeerType, String participant, String threadId, String voicemailResourcePath) {
		return placeCallToVoicemail(callGuid, mediaPeerType, participant, threadId, voicemailResourcePath, "");
	}
	@Override
	public int placeCall(String callGuid, CallHandler.MEDIA_PEER_TYPE mediaPeerType, String[] participantList, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration, String threadId, String messageId, String subject, String conversationType, String meetingInfo, String endpointMetaData, String onBehalfOf, String emergencyContent, String broadcastContext) {
		return placeCall(NativeStringConvert.ConvertToNativeBytes(callGuid), mediaPeerType, NativeStringConvert.ConvertArrToNativeByteArr(participantList), isVideoEnabled, isGoLive, allowHostless, enableGroupCallMeetupGeneration, NativeStringConvert.ConvertToNativeBytes(threadId), NativeStringConvert.ConvertToNativeBytes(messageId), NativeStringConvert.ConvertToNativeBytes(subject), NativeStringConvert.ConvertToNativeBytes(conversationType), NativeStringConvert.ConvertToNativeBytes(meetingInfo), NativeStringConvert.ConvertToNativeBytes(endpointMetaData), NativeStringConvert.ConvertToNativeBytes(onBehalfOf), NativeStringConvert.ConvertToNativeBytes(emergencyContent), NativeStringConvert.ConvertToNativeBytes(broadcastContext));
	}

	private native int placeCall(byte[] callGuid, CallHandler.MEDIA_PEER_TYPE mediaPeerType, byte[][] participantList, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration, byte[] threadId, byte[] messageId, byte[] subject, byte[] conversationType, byte[] meetingInfo, byte[] endpointMetaData, byte[] onBehalfOf, byte[] emergencyContent, byte[] broadcastContext);
	@Override
	public int placeCall(String callGuid, CallHandler.MEDIA_PEER_TYPE mediaPeerType) {
		return placeCall(callGuid, mediaPeerType, null, false, false, true, false, "", "", "", "", "", "", "", "", "");
	}
	@Override
	public int placeCall(String callGuid, CallHandler.MEDIA_PEER_TYPE mediaPeerType, String[] participantList) {
		return placeCall(callGuid, mediaPeerType, participantList, false, false, true, false, "", "", "", "", "", "", "", "", "");
	}
	@Override
	public int placeCall(String callGuid, CallHandler.MEDIA_PEER_TYPE mediaPeerType, String[] participantList, boolean isVideoEnabled) {
		return placeCall(callGuid, mediaPeerType, participantList, isVideoEnabled, false, true, false, "", "", "", "", "", "", "", "", "");
	}
	@Override
	public int placeCall(String callGuid, CallHandler.MEDIA_PEER_TYPE mediaPeerType, String[] participantList, boolean isVideoEnabled, boolean isGoLive) {
		return placeCall(callGuid, mediaPeerType, participantList, isVideoEnabled, isGoLive, true, false, "", "", "", "", "", "", "", "", "");
	}
	@Override
	public int placeCall(String callGuid, CallHandler.MEDIA_PEER_TYPE mediaPeerType, String[] participantList, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless) {
		return placeCall(callGuid, mediaPeerType, participantList, isVideoEnabled, isGoLive, allowHostless, false, "", "", "", "", "", "", "", "", "");
	}
	@Override
	public int placeCall(String callGuid, CallHandler.MEDIA_PEER_TYPE mediaPeerType, String[] participantList, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration) {
		return placeCall(callGuid, mediaPeerType, participantList, isVideoEnabled, isGoLive, allowHostless, enableGroupCallMeetupGeneration, "", "", "", "", "", "", "", "", "");
	}
	@Override
	public int placeCall(String callGuid, CallHandler.MEDIA_PEER_TYPE mediaPeerType, String[] participantList, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration, String threadId) {
		return placeCall(callGuid, mediaPeerType, participantList, isVideoEnabled, isGoLive, allowHostless, enableGroupCallMeetupGeneration, threadId, "", "", "", "", "", "", "", "");
	}
	@Override
	public int placeCall(String callGuid, CallHandler.MEDIA_PEER_TYPE mediaPeerType, String[] participantList, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration, String threadId, String messageId) {
		return placeCall(callGuid, mediaPeerType, participantList, isVideoEnabled, isGoLive, allowHostless, enableGroupCallMeetupGeneration, threadId, messageId, "", "", "", "", "", "", "");
	}
	@Override
	public int placeCall(String callGuid, CallHandler.MEDIA_PEER_TYPE mediaPeerType, String[] participantList, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration, String threadId, String messageId, String subject) {
		return placeCall(callGuid, mediaPeerType, participantList, isVideoEnabled, isGoLive, allowHostless, enableGroupCallMeetupGeneration, threadId, messageId, subject, "", "", "", "", "", "");
	}
	@Override
	public int placeCall(String callGuid, CallHandler.MEDIA_PEER_TYPE mediaPeerType, String[] participantList, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration, String threadId, String messageId, String subject, String conversationType) {
		return placeCall(callGuid, mediaPeerType, participantList, isVideoEnabled, isGoLive, allowHostless, enableGroupCallMeetupGeneration, threadId, messageId, subject, conversationType, "", "", "", "", "");
	}
	@Override
	public int placeCall(String callGuid, CallHandler.MEDIA_PEER_TYPE mediaPeerType, String[] participantList, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration, String threadId, String messageId, String subject, String conversationType, String meetingInfo) {
		return placeCall(callGuid, mediaPeerType, participantList, isVideoEnabled, isGoLive, allowHostless, enableGroupCallMeetupGeneration, threadId, messageId, subject, conversationType, meetingInfo, "", "", "", "");
	}
	@Override
	public int placeCall(String callGuid, CallHandler.MEDIA_PEER_TYPE mediaPeerType, String[] participantList, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration, String threadId, String messageId, String subject, String conversationType, String meetingInfo, String endpointMetaData) {
		return placeCall(callGuid, mediaPeerType, participantList, isVideoEnabled, isGoLive, allowHostless, enableGroupCallMeetupGeneration, threadId, messageId, subject, conversationType, meetingInfo, endpointMetaData, "", "", "");
	}
	@Override
	public int placeCall(String callGuid, CallHandler.MEDIA_PEER_TYPE mediaPeerType, String[] participantList, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration, String threadId, String messageId, String subject, String conversationType, String meetingInfo, String endpointMetaData, String onBehalfOf) {
		return placeCall(callGuid, mediaPeerType, participantList, isVideoEnabled, isGoLive, allowHostless, enableGroupCallMeetupGeneration, threadId, messageId, subject, conversationType, meetingInfo, endpointMetaData, onBehalfOf, "", "");
	}
	@Override
	public int placeCall(String callGuid, CallHandler.MEDIA_PEER_TYPE mediaPeerType, String[] participantList, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration, String threadId, String messageId, String subject, String conversationType, String meetingInfo, String endpointMetaData, String onBehalfOf, String emergencyContent) {
		return placeCall(callGuid, mediaPeerType, participantList, isVideoEnabled, isGoLive, allowHostless, enableGroupCallMeetupGeneration, threadId, messageId, subject, conversationType, meetingInfo, endpointMetaData, onBehalfOf, emergencyContent, "");
	}
	@Override
	public void provideCallQualityFeedback(String callId, String participantId, String questionaryId, String trackingReason, CallHandler.QUALITYRATING rating, String problemTokens) {
		provideCallQualityFeedback(NativeStringConvert.ConvertToNativeBytes(callId), NativeStringConvert.ConvertToNativeBytes(participantId), NativeStringConvert.ConvertToNativeBytes(questionaryId), NativeStringConvert.ConvertToNativeBytes(trackingReason), rating, NativeStringConvert.ConvertToNativeBytes(problemTokens));
	}

	private native void provideCallQualityFeedback(byte[] callId, byte[] participantId, byte[] questionaryId, byte[] trackingReason, CallHandler.QUALITYRATING rating, byte[] problemTokens);
	@Override
	public boolean publishState(int callObjectId, String type, CallHandler.PUBLISH_STATE_LEVEL level, String content, String causeId, String[] participantIds) {
		return publishState(callObjectId, NativeStringConvert.ConvertToNativeBytes(type), level, NativeStringConvert.ConvertToNativeBytes(content), NativeStringConvert.ConvertToNativeBytes(causeId), NativeStringConvert.ConvertArrToNativeByteArr(participantIds));
	}

	private native boolean publishState(int callObjectId, byte[] type, CallHandler.PUBLISH_STATE_LEVEL level, byte[] content, byte[] causeId, byte[][] participantIds);
	@Override
	public boolean publishState(int callObjectId, String type, CallHandler.PUBLISH_STATE_LEVEL level, String content, String causeId) {
		return publishState(callObjectId, type, level, content, causeId, null);
	}
	@Override
	public boolean publishStatesForEveryone(int callObjectId, String type, CallHandler.PUBLISH_STATE_LEVEL level, String content, String causeId) {
		return publishStatesForEveryone(callObjectId, NativeStringConvert.ConvertToNativeBytes(type), level, NativeStringConvert.ConvertToNativeBytes(content), NativeStringConvert.ConvertToNativeBytes(causeId));
	}

	private native boolean publishStatesForEveryone(int callObjectId, byte[] type, CallHandler.PUBLISH_STATE_LEVEL level, byte[] content, byte[] causeId);
	@Override
	public native void rejectLocally(int callObjectId, CallHandler.REJECT_TYPE rejectType);

	@Override
	public void rejectLocally(int callObjectId) {
		rejectLocally(callObjectId, CallHandler.REJECT_TYPE.REJECT_TYPE_NONE);
	}
	@Override
	public native void removeParticipant(int participantObjectId, CallHandler.REMOVE_ENDPOINT_SCOPE removeEndpointScope);

	@Override
	public void removeParticipant(int participantObjectId) {
		removeParticipant(participantObjectId, CallHandler.REMOVE_ENDPOINT_SCOPE.REMOVE_ENDPOINT_SCOPE_NONE);
	}
	@Override
	public void removeParticipantByMri(int callObjectId, String participantMri, String endpoint, CallHandler.REMOVE_ENDPOINT_SCOPE removeEndpointScope) {
		removeParticipantByMri(callObjectId, NativeStringConvert.ConvertToNativeBytes(participantMri), NativeStringConvert.ConvertToNativeBytes(endpoint), removeEndpointScope);
	}

	private native void removeParticipantByMri(int callObjectId, byte[] participantMri, byte[] endpoint, CallHandler.REMOVE_ENDPOINT_SCOPE removeEndpointScope);
	@Override
	public void removeParticipantByMri(int callObjectId, String participantMri) {
		removeParticipantByMri(callObjectId, participantMri, "", CallHandler.REMOVE_ENDPOINT_SCOPE.REMOVE_ENDPOINT_SCOPE_NONE);
	}
	@Override
	public void removeParticipantByMri(int callObjectId, String participantMri, String endpoint) {
		removeParticipantByMri(callObjectId, participantMri, endpoint, CallHandler.REMOVE_ENDPOINT_SCOPE.REMOVE_ENDPOINT_SCOPE_NONE);
	}
	@Override
	public boolean removeState(int callObjectId, String[] stateIds, String causeId) {
		return removeState(callObjectId, NativeStringConvert.ConvertArrToNativeByteArr(stateIds), NativeStringConvert.ConvertToNativeBytes(causeId));
	}

	private native boolean removeState(int callObjectId, byte[][] stateIds, byte[] causeId);
	@Override
	public boolean removeStatesForEveryone(int callObjectId, String type, String causeId) {
		return removeStatesForEveryone(callObjectId, NativeStringConvert.ConvertToNativeBytes(type), NativeStringConvert.ConvertToNativeBytes(causeId));
	}

	private native boolean removeStatesForEveryone(int callObjectId, byte[] type, byte[] causeId);
	@Override
	public boolean searchParticipants(int callObjectId, String searchOptionsParametersJson, String causeId) {
		return searchParticipants(callObjectId, NativeStringConvert.ConvertToNativeBytes(searchOptionsParametersJson), NativeStringConvert.ConvertToNativeBytes(causeId));
	}

	private native boolean searchParticipants(int callObjectId, byte[] searchOptionsParametersJson, byte[] causeId);
	@Override
	public void setLocationInfo(CallHandler.LOCATION_INFO_TYPE infoType, String contentJson) {
		setLocationInfo(infoType, NativeStringConvert.ConvertToNativeBytes(contentJson));
	}

	private native void setLocationInfo(CallHandler.LOCATION_INFO_TYPE infoType, byte[] contentJson);
	@Override
	public void setLocationInfo(CallHandler.LOCATION_INFO_TYPE infoType) {
		setLocationInfo(infoType, "");
	}
	@Override
	public boolean setParticipantSpatialAudioPositions(int callObjectId, String participantSpatialAudioPositionsJson) {
		return setParticipantSpatialAudioPositions(callObjectId, NativeStringConvert.ConvertToNativeBytes(participantSpatialAudioPositionsJson));
	}

	private native boolean setParticipantSpatialAudioPositions(int callObjectId, byte[] participantSpatialAudioPositionsJson);
	@Override
	public boolean startCallPark(int callObjectId, CallHandler.PARK_CONTEXT parkContext, String causeId) {
		return startCallPark(callObjectId, parkContext, NativeStringConvert.ConvertToNativeBytes(causeId));
	}

	private native boolean startCallPark(int callObjectId, CallHandler.PARK_CONTEXT parkContext, byte[] causeId);
	@Override
	public boolean startCallPark(int callObjectId, CallHandler.PARK_CONTEXT parkContext) {
		return startCallPark(callObjectId, parkContext, "");
	}
	@Override
	public boolean startCallRedirect(int callObjectId, String causeId, int redirectOptionObjectId) {
		return startCallRedirect(callObjectId, NativeStringConvert.ConvertToNativeBytes(causeId), redirectOptionObjectId);
	}

	private native boolean startCallRedirect(int callObjectId, byte[] causeId, int redirectOptionObjectId);
	@Override
	public boolean startCallTransfer(int callObjectId, String participantId, CallHandler.TRANSFER_TYPE transferType, int transferOptionsObjId) {
		return startCallTransfer(callObjectId, NativeStringConvert.ConvertToNativeBytes(participantId), transferType, transferOptionsObjId);
	}

	private native boolean startCallTransfer(int callObjectId, byte[] participantId, CallHandler.TRANSFER_TYPE transferType, int transferOptionsObjId);
	@Override
	public boolean startCallTransfer(int callObjectId, String participantId) {
		return startCallTransfer(callObjectId, participantId, CallHandler.TRANSFER_TYPE.TRANSFER_STANDARD, 0);
	}
	@Override
	public boolean startCallTransfer(int callObjectId, String participantId, CallHandler.TRANSFER_TYPE transferType) {
		return startCallTransfer(callObjectId, participantId, transferType, 0);
	}
	@Override
	public int startCallUnpark(String callGuid, int sessionParametersObjectId, CallHandler.PARK_CONTEXT parkContext, String pickupCode) {
		return startCallUnpark(NativeStringConvert.ConvertToNativeBytes(callGuid), sessionParametersObjectId, parkContext, NativeStringConvert.ConvertToNativeBytes(pickupCode));
	}

	private native int startCallUnpark(byte[] callGuid, int sessionParametersObjectId, CallHandler.PARK_CONTEXT parkContext, byte[] pickupCode);
	@Override
	public boolean startConsultativeCallTransfer(int consultativeCallObjectId, int transfereeCallObjectId, String transferTargetParticipantId, String causeId, int transferOptionsObjId) {
		return startConsultativeCallTransfer(consultativeCallObjectId, transfereeCallObjectId, NativeStringConvert.ConvertToNativeBytes(transferTargetParticipantId), NativeStringConvert.ConvertToNativeBytes(causeId), transferOptionsObjId);
	}

	private native boolean startConsultativeCallTransfer(int consultativeCallObjectId, int transfereeCallObjectId, byte[] transferTargetParticipantId, byte[] causeId, int transferOptionsObjId);
	@Override
	public boolean startConsultativeCallTransfer(int consultativeCallObjectId, int transfereeCallObjectId) {
		return startConsultativeCallTransfer(consultativeCallObjectId, transfereeCallObjectId, "", "", 0);
	}
	@Override
	public boolean startConsultativeCallTransfer(int consultativeCallObjectId, int transfereeCallObjectId, String transferTargetParticipantId) {
		return startConsultativeCallTransfer(consultativeCallObjectId, transfereeCallObjectId, transferTargetParticipantId, "", 0);
	}
	@Override
	public boolean startConsultativeCallTransfer(int consultativeCallObjectId, int transfereeCallObjectId, String transferTargetParticipantId, String causeId) {
		return startConsultativeCallTransfer(consultativeCallObjectId, transfereeCallObjectId, transferTargetParticipantId, causeId, 0);
	}
	@Override
	public boolean startFaceStream(int callObjectId, String deviceId, int recipientMediaStreamId) {
		return startFaceStream(callObjectId, NativeStringConvert.ConvertToNativeBytes(deviceId), recipientMediaStreamId);
	}

	private native boolean startFaceStream(int callObjectId, byte[] deviceId, int recipientMediaStreamId);
	@Override
	public boolean startFaceStream() {
		return startFaceStream(0, "", 0);
	}
	@Override
	public boolean startFaceStream(int callObjectId) {
		return startFaceStream(callObjectId, "", 0);
	}
	@Override
	public boolean startFaceStream(int callObjectId, String deviceId) {
		return startFaceStream(callObjectId, deviceId, 0);
	}
	@Override
	public boolean startMultichannelAudioDevice(int callObjectId, String deviceId, int recipientId) {
		return startMultichannelAudioDevice(callObjectId, NativeStringConvert.ConvertToNativeBytes(deviceId), recipientId);
	}

	private native boolean startMultichannelAudioDevice(int callObjectId, byte[] deviceId, int recipientId);
	@Override
	public int startSignalingSessionWithMeetingData(String callGuid, String meetingData, String resurrectPreference, CallHandler.MEDIA_PEER_TYPE mediaPeerType, int sessionParametersObjectId, String[] participants) {
		return startSignalingSessionWithMeetingData(NativeStringConvert.ConvertToNativeBytes(callGuid), NativeStringConvert.ConvertToNativeBytes(meetingData), NativeStringConvert.ConvertToNativeBytes(resurrectPreference), mediaPeerType, sessionParametersObjectId, NativeStringConvert.ConvertArrToNativeByteArr(participants));
	}

	private native int startSignalingSessionWithMeetingData(byte[] callGuid, byte[] meetingData, byte[] resurrectPreference, CallHandler.MEDIA_PEER_TYPE mediaPeerType, int sessionParametersObjectId, byte[][] participants);
	@Override
	public int startSignalingSessionWithMeetingData(String callGuid, String meetingData, String resurrectPreference, CallHandler.MEDIA_PEER_TYPE mediaPeerType, int sessionParametersObjectId) {
		return startSignalingSessionWithMeetingData(callGuid, meetingData, resurrectPreference, mediaPeerType, sessionParametersObjectId, null);
	}
	@Override
	public int startSignalingSession(String callGuid, CallHandler.MEDIA_PEER_TYPE mediaPeerType, int sessionParametersObjectId, String[] participantList) {
		return startSignalingSession(NativeStringConvert.ConvertToNativeBytes(callGuid), mediaPeerType, sessionParametersObjectId, NativeStringConvert.ConvertArrToNativeByteArr(participantList));
	}

	private native int startSignalingSession(byte[] callGuid, CallHandler.MEDIA_PEER_TYPE mediaPeerType, int sessionParametersObjectId, byte[][] participantList);
	@Override
	public int startSignalingSession(String callGuid, CallHandler.MEDIA_PEER_TYPE mediaPeerType, int sessionParametersObjectId) {
		return startSignalingSession(callGuid, mediaPeerType, sessionParametersObjectId, null);
	}
	@Override
	public boolean startTransferTargetCall(int callObjectId, boolean isVideoEnabled, String threadId, String messageId, CallHandler.MEDIA_PEER_TYPE mediaPeerType) {
		return startTransferTargetCall(callObjectId, isVideoEnabled, NativeStringConvert.ConvertToNativeBytes(threadId), NativeStringConvert.ConvertToNativeBytes(messageId), mediaPeerType);
	}

	private native boolean startTransferTargetCall(int callObjectId, boolean isVideoEnabled, byte[] threadId, byte[] messageId, CallHandler.MEDIA_PEER_TYPE mediaPeerType);
	@Override
	public boolean startTransferTargetCall(int callObjectId) {
		return startTransferTargetCall(callObjectId, false, "", "", CallHandler.MEDIA_PEER_TYPE.CONSUMER_TWOPARTY);
	}
	@Override
	public boolean startTransferTargetCall(int callObjectId, boolean isVideoEnabled) {
		return startTransferTargetCall(callObjectId, isVideoEnabled, "", "", CallHandler.MEDIA_PEER_TYPE.CONSUMER_TWOPARTY);
	}
	@Override
	public boolean startTransferTargetCall(int callObjectId, boolean isVideoEnabled, String threadId) {
		return startTransferTargetCall(callObjectId, isVideoEnabled, threadId, "", CallHandler.MEDIA_PEER_TYPE.CONSUMER_TWOPARTY);
	}
	@Override
	public boolean startTransferTargetCall(int callObjectId, boolean isVideoEnabled, String threadId, String messageId) {
		return startTransferTargetCall(callObjectId, isVideoEnabled, threadId, messageId, CallHandler.MEDIA_PEER_TYPE.CONSUMER_TWOPARTY);
	}
	@Override
	public native boolean stopFaceStream(int callObjectId);

	@Override
	public boolean stopFaceStream() {
		return stopFaceStream(0);
	}
	@Override
	public native boolean stopMultichannelAudioDevice(int callObjectId);

	@Override
	public int subscribeToSignalingSessionWithMeetingData(String meetingData, String resurrectPreference, String joinContext, int sessionParametersObjectId) {
		return subscribeToSignalingSessionWithMeetingData(NativeStringConvert.ConvertToNativeBytes(meetingData), NativeStringConvert.ConvertToNativeBytes(resurrectPreference), NativeStringConvert.ConvertToNativeBytes(joinContext), sessionParametersObjectId);
	}

	private native int subscribeToSignalingSessionWithMeetingData(byte[] meetingData, byte[] resurrectPreference, byte[] joinContext, int sessionParametersObjectId);
	@Override
	public int subscribeToSignalingSession(String joinContext, int sessionParametersObjectId) {
		return subscribeToSignalingSession(NativeStringConvert.ConvertToNativeBytes(joinContext), sessionParametersObjectId);
	}

	private native int subscribeToSignalingSession(byte[] joinContext, int sessionParametersObjectId);
	@Override
	public int subscribe(String joinContext, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration, String threadId, String messageId, String subject, String conversationType, String meetingInfo, String endpointMetaData, String onBehalfOf) {
		return subscribe(NativeStringConvert.ConvertToNativeBytes(joinContext), isVideoEnabled, isGoLive, allowHostless, enableGroupCallMeetupGeneration, NativeStringConvert.ConvertToNativeBytes(threadId), NativeStringConvert.ConvertToNativeBytes(messageId), NativeStringConvert.ConvertToNativeBytes(subject), NativeStringConvert.ConvertToNativeBytes(conversationType), NativeStringConvert.ConvertToNativeBytes(meetingInfo), NativeStringConvert.ConvertToNativeBytes(endpointMetaData), NativeStringConvert.ConvertToNativeBytes(onBehalfOf));
	}

	private native int subscribe(byte[] joinContext, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration, byte[] threadId, byte[] messageId, byte[] subject, byte[] conversationType, byte[] meetingInfo, byte[] endpointMetaData, byte[] onBehalfOf);
	@Override
	public int subscribe(String joinContext) {
		return subscribe(joinContext, false, false, true, false, "", "", "", "", "", "", "");
	}
	@Override
	public int subscribe(String joinContext, boolean isVideoEnabled) {
		return subscribe(joinContext, isVideoEnabled, false, true, false, "", "", "", "", "", "", "");
	}
	@Override
	public int subscribe(String joinContext, boolean isVideoEnabled, boolean isGoLive) {
		return subscribe(joinContext, isVideoEnabled, isGoLive, true, false, "", "", "", "", "", "", "");
	}
	@Override
	public int subscribe(String joinContext, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless) {
		return subscribe(joinContext, isVideoEnabled, isGoLive, allowHostless, false, "", "", "", "", "", "", "");
	}
	@Override
	public int subscribe(String joinContext, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration) {
		return subscribe(joinContext, isVideoEnabled, isGoLive, allowHostless, enableGroupCallMeetupGeneration, "", "", "", "", "", "", "");
	}
	@Override
	public int subscribe(String joinContext, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration, String threadId) {
		return subscribe(joinContext, isVideoEnabled, isGoLive, allowHostless, enableGroupCallMeetupGeneration, threadId, "", "", "", "", "", "");
	}
	@Override
	public int subscribe(String joinContext, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration, String threadId, String messageId) {
		return subscribe(joinContext, isVideoEnabled, isGoLive, allowHostless, enableGroupCallMeetupGeneration, threadId, messageId, "", "", "", "", "");
	}
	@Override
	public int subscribe(String joinContext, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration, String threadId, String messageId, String subject) {
		return subscribe(joinContext, isVideoEnabled, isGoLive, allowHostless, enableGroupCallMeetupGeneration, threadId, messageId, subject, "", "", "", "");
	}
	@Override
	public int subscribe(String joinContext, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration, String threadId, String messageId, String subject, String conversationType) {
		return subscribe(joinContext, isVideoEnabled, isGoLive, allowHostless, enableGroupCallMeetupGeneration, threadId, messageId, subject, conversationType, "", "", "");
	}
	@Override
	public int subscribe(String joinContext, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration, String threadId, String messageId, String subject, String conversationType, String meetingInfo) {
		return subscribe(joinContext, isVideoEnabled, isGoLive, allowHostless, enableGroupCallMeetupGeneration, threadId, messageId, subject, conversationType, meetingInfo, "", "");
	}
	@Override
	public int subscribe(String joinContext, boolean isVideoEnabled, boolean isGoLive, boolean allowHostless, boolean enableGroupCallMeetupGeneration, String threadId, String messageId, String subject, String conversationType, String meetingInfo, String endpointMetaData) {
		return subscribe(joinContext, isVideoEnabled, isGoLive, allowHostless, enableGroupCallMeetupGeneration, threadId, messageId, subject, conversationType, meetingInfo, endpointMetaData, "");
	}
	@Override
	public boolean testHook(int callObjectId, String argument) {
		return testHook(callObjectId, NativeStringConvert.ConvertToNativeBytes(argument));
	}

	private native boolean testHook(int callObjectId, byte[] argument);
	@Override
	public native boolean unpark(int callObjectId, int parkUnparkParametersObjectId);

	@Override
	public native void unsubscribe(int callObjectId);

	@Override
	public boolean updateMeetingGroups(int callObjectId, String causeId, int updateMeetingGroupParametersObjectId) {
		return updateMeetingGroups(callObjectId, NativeStringConvert.ConvertToNativeBytes(causeId), updateMeetingGroupParametersObjectId);
	}

	private native boolean updateMeetingGroups(int callObjectId, byte[] causeId, int updateMeetingGroupParametersObjectId);
	@Override
	public boolean updateMeetingLiveState(int callObjectId, String causeId, int updateMeetingLiveStateParametersObjectId) {
		return updateMeetingLiveState(callObjectId, NativeStringConvert.ConvertToNativeBytes(causeId), updateMeetingLiveStateParametersObjectId);
	}

	private native boolean updateMeetingLiveState(int callObjectId, byte[] causeId, int updateMeetingLiveStateParametersObjectId);
	@Override
	public boolean updateMeetingRoles(int callObjectId, String[] participantList, String meetingRole, String causeId) {
		return updateMeetingRoles(callObjectId, NativeStringConvert.ConvertArrToNativeByteArr(participantList), NativeStringConvert.ConvertToNativeBytes(meetingRole), NativeStringConvert.ConvertToNativeBytes(causeId));
	}

	private native boolean updateMeetingRoles(int callObjectId, byte[][] participantList, byte[] meetingRole, byte[] causeId);
	@Override
	public boolean updateMeetingRoles(int callObjectId, String[] participantList, String meetingRole) {
		return updateMeetingRoles(callObjectId, participantList, meetingRole, "");
	}
	@Override
	public boolean updateMeetingSettingsJson(int callObjectId, String meetingSettingsParametersJson, String causeId) {
		return updateMeetingSettingsJson(callObjectId, NativeStringConvert.ConvertToNativeBytes(meetingSettingsParametersJson), NativeStringConvert.ConvertToNativeBytes(causeId));
	}

	private native boolean updateMeetingSettingsJson(int callObjectId, byte[] meetingSettingsParametersJson, byte[] causeId);
	@Override
	public boolean updateParticipantInterpretationState(int callObjectId, String causeId, int updateParticipantInterpretationStateParametersObjectId) {
		return updateParticipantInterpretationState(callObjectId, NativeStringConvert.ConvertToNativeBytes(causeId), updateParticipantInterpretationStateParametersObjectId);
	}

	private native boolean updateParticipantInterpretationState(int callObjectId, byte[] causeId, int updateParticipantInterpretationStateParametersObjectId);
}

