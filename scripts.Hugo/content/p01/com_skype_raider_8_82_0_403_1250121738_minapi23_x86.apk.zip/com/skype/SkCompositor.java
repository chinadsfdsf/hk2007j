/* =============================================================================
 *                      GENERATED FILE - DO NOT MODIFY
 * =============================================================================
 * Copyright © Microsoft Corporation. All rights reserved.
 * 
 */
package com.skype;
import android.support.v4.util.SparseArrayCompat;
import java.util.Set;
import java.util.HashSet;
import java.lang.ref.ReferenceQueue;
import com.skype.NativeStringConvert;

public interface SkCompositor extends ObjectInterface {
	public interface SkCompositorIListener {
		void onCompositorError(SkCompositor sender, String error);
		void onDispose(SkCompositor sender);
		void onLayoutUpdate(SkCompositor sender, String layout);
	}

	public void addListener(SkCompositorIListener listener);

	public void removeListener(SkCompositorIListener listener);

	
	public void addVideoView(int viewId, int videoObjectID);

	public void dispose();

	public void removeVideoView(int viewId);

	public void start();

	public void stop();

	public boolean updateLayout(String layout);

}

